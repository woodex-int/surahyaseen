# Agent 01 — Brand, Content & Archive

## Approved vocabulary
**Biya's Art Gallery** · **Art | Poetry | Culture | Lahore** · Biya Jee · Thread Art · The Third Art · Folios · Mehfil · Muqalma · Punjabi Verha · Ishq · private viewing · collector enquiry · Request Price.

## Name requirement
`Biya Jee — [APPROVED ENGLISH SPELLING] Khursheed` is **Pending Verification**. Do not publish alternative English spellings until owner approval.

## Claim register
| Claim / content | Status | Publication instruction |
|---|---|---|
| Lahore-based cultural gallery platform | Verified | Publish as supplied project context. |
| Biya Jee is artist, poet, writer and cultural voice | Verified | Publish only in this broad approved form. |
| The Third Art | Pending Verification | Publish only as an artist-led project; obtain approved definition. |
| 70 Surah Rehman folios | Pending Verification | Do not present as complete until 70 individual images and records arrive. |
| 20+ books | Pending Verification | Do not publish count / titles until library register is supplied. |
| Punjabi Verha public identity | Verified | Build as an independent content pillar; facts require registers. |
| Awards, “first”, national asset, ownership, museum claims | Not for Publication | Require primary evidence. |

## Final content map
### Home
Brand introduction; real featured works only; collector enquiry; events; cultural pillars.
### Artworks
Available Works, Collections, The Third Art, Archive / Sold Works, Gallery Artists. All records require asset and verification status.
### Biya Jee
Biography, Art & Installations, Poetry & Writing, Books & Library, Media & Interviews.
### Punjabi Verha
About, Monthly Events, Mushairas, Muqalma & Dialogues, Video Archive, Media Coverage, Join / Collaborate.
### Other pillars
Exhibitions & Events; Projects & Interiors; Commissions & Custom Studio; Trade & Hospitality; Media & Press; Visit / Contact.

## WordPress-ready registers
### Artwork / collection register
`slug, title, artist, collection, medium, year, dimensions, availability, price_policy, images, story, certificate_provenance, verification_status, source_owner, rights_status`

### Surah Rehman folio register
`folio_no, title_or_verse, approved_translation, medium, dimensions, year, image_full, image_detail, availability, rights_status, verification_status, archive_note`

### Book / library register
`title, author, cover, publication_year, language, publisher, ISBN, synopsis, approved_excerpt, availability, purchase_or_enquiry_CTA, verification_status`

### Punjabi Verha event / video / media register
`type, title, date, venue, guests, programme, images, video_url, press_url, approved_summary, RSVP_or_collaboration_CTA, verification_status`

### Press register
`outlet, publication_date, source_url, thumbnail, verified_summary, related_item, rights_status, verification_status`

## Missing assets
| Priority | Asset | Owner | Status |
|---|---|---|---|
| P0 | Official founder spelling | Gallery owner | Pending Verification |
| P0 | 70 individual Surah Rehman folios + metadata | Archive owner | Missing |
| P0 | Artwork rights / availability / metadata | Gallery curator | Missing |
| P0 | Contact and policy information | Business owner | Missing |
| P1 | 20+ book covers and bibliographic records | Library owner | Missing |
| P1 | Punjabi Verha event, video and media sources | Punjabi Verha team | Missing |
| P1 | Approved founder CV and media list | Biya Jee / representative | Missing |

## English SEO map
| Route / future route | SEO title | Meta description status |
|---|---|---|
| Home | Biya's Art Gallery | Art, Poetry & Culture in Lahore | Pending approved final copy |
| Artworks | Artworks | Biya's Art Gallery | Pending real catalogue |
| Third Art | The Third Art | Biya's Art Gallery | Pending approved definition |
| Biya Jee | Biya Jee | Artist, Poet & Cultural Voice | Pending official spelling |
| Punjabi Verha | Punjabi Verha | Culture, Mehfil & Dialogue | Pending source register |
| Books | Books & Library | Biya Jee | Pending bibliographic inventory |
| Events | Exhibitions & Events | Biya's Art Gallery | Pending event records |
| Contact | Visit Biya's Art Gallery | Lahore | Pending contacts |

## Urdu / Punjabi queue
- Founder biography (English source approved first)
- Punjabi Verha About
- Event titles and descriptions
- Poetry titles, excerpts and translations
- Folio titles / approved translations
- Contact and policy summaries

## Stage 2 handoff
Agent 02 may create only empty data-driven templates and clearly marked pending states until P0 assets are approved. No real-archive claims, direct checkout for originals or unverified founder spelling may enter production.