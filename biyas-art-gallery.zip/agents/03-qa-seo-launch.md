# Agent 03 — QA, SEO & Launch (Stage 3 Handoff)

## Entry condition
Begin after Stage 2 route and form implementation is complete.

## Required audit areas
Navigation and responsive views; validation; WhatsApp and Request Price flows; viewing/trade/RSVP forms; keyboard, focus, contrast and reduced motion; image alt text/captions; titles/meta/canonicals/OG; sitemap/robots/internal links/404; structured data; privacy/terms/copyright/commission/delivery/returns; spam protection; analytics consent; backups; image optimisation; placeholder and unverified-claim audits.

## P0/P1/P2 report format
For every finding report: exact route, issue, evidence, priority, owner and fix recommendation.

- **P0:** launch blocker — broken forms, wrong claims, placeholder art presented as real, missing legal/contact essentials.
- **P1:** immediate post-launch fix — SEO metadata gaps, non-critical performance/accessibility issues.
- **P2:** enhancement — optional UX/content improvement.
