# Agent 02 — Frontend & WordPress System

**Stage:** 2 planning active. No production frontend changes are included in this document.

## Approved input
Agent 01 content inventory is the source of truth. See `../STAGE2_FRONTEND_WORDPRESS_TEMPLATE_PLAN.md` for the complete implementation plan.

## Mandatory implementation controls
- One header, footer and final navigation system.
- Data-driven templates only; no duplicate images as fake archive records.
- Records publish only if `verification_status = Verified` and rights are approved.
- Pending records render neutral empty / holding states.
- Frontend displays only `Biya Jee` until official English spelling is confirmed; the full-name verification state is admin-only.
- Original works and Third Art folios use request-price / enquiry flows, never checkout.
- Checkout is disabled for books, prints and editions until commercial policy approval.

## WordPress build scope
CPTs: Artwork, Collection, Artist, Exhibition/Event, Project/Installation, Book/Library Item, Punjabi Verha Event, Press/Media Item, Journal Article.

Taxonomies: availability, `artwork_collection`, medium, art type, event type, language, year, location and project type. Artist is the `artist_profile` ACF Relationship field targeting the Artist CPT; it is not a taxonomy. Third Art folios are Artwork records using `art_type = third-art-folio`. Event records require one of: exhibition, mushaira, muqalma, talk, private-viewing or other.

## Acceptance criteria for Stage 2
1. Responsive at 360px, 768px and desktop.
2. Keyboard-accessible menus, galleries, drawers and lightboxes.
3. Reduced-motion support.
4. Image performance safeguards.
5. Every form has a verified destination, validation and consent before live deployment.
6. Stage 3 receives route, component, form, metadata and known-gap handoff.