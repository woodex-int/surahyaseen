# Biya's Art Gallery — WordPress, Elementor & XPRO Migration Masterplan

**Migration target:** connected WordPress site  
**Builder:** Elementor Containers only  
**Header / footer:** XPRO custom templates, saved to XPRO Library  
**Forms:** WPForms  
**Element interpretation / structure:** Novamira  
**Constraint:** Atomic Editor disabled; do not use Atomic Elements. Do not use Elementor HTML widgets or Elementor Pro widgets.

---

## 0. Approval and safety gate

Before migration begins, confirm all Stage 1 content rules remain active:

- Public founder label is **Biya Jee** only until English spelling approval is supplied.
- Original artworks and Third Art folios use Request Price / Request Details / Private Viewing — no checkout.
- The Surah Rehman archive is a holding state until approved `Artwork` records with `art_type = third-art-folio` exist.
- AI / sample / repeated images cannot appear as genuine artworks.
- Pending Verification content stays unpublished or in a clearly labelled editorial holding state.

---

## 1. WordPress foundation

### Required plugin / capability check
- Elementor active.
- Elementor Atomic Editor disabled.
- XPRO active and custom header/footer builder available.
- WPForms active.
- Novamira active.
- Permalinks set to Post Name.
- Staging or backup point confirmed before migration.

### Theme approach
- Use a lightweight Elementor-compatible theme / child theme.
- Use global Elementor Site Settings for brand colours, type, buttons, containers and responsive rules.
- Do not duplicate brand styles page by page.

### Elementor global design tokens
| Token | Value / direction |
|---|---|
| Evergreen | `#122622` |
| Espresso | `#18130E` |
| Gold | `#C9A54D` |
| Champagne | `#F7F1E5` |
| Display type | Editorial serif |
| Interface type | Clean sans / mono metadata |
| Container max-width | 1280px desktop, with 7vw mobile gutters |
| Motion | restrained transform / opacity only; reduced-motion alternative required |

---

## 2. WordPress content architecture

### Custom post types
- Artwork
- Collection
- Artist
- Event
- Project / Installation
- Book / Library Item
- Punjabi Verha Event
- Press / Media Item
- Journal Article

### Internal taxonomies
- `artwork_collection` — public label Collection
- `availability`
- `medium`
- `art_type`
- `year`
- `language`
- `event_type`
- `location`
- `project_type`

**Do not create** an `artist` taxonomy or `artwork_artist` taxonomy. Use ACF Post Object / Relationship field `artist_profile`, targeting the Artist CPT.

### Third Art / Surah Rehman data rule
Store every approved folio as an **Artwork CPT** item with:

```text
art_type = third-art-folio
folio_number
folio_image
title_or_verse
approved_translation
archive_note
rights_status
verification_status
```

The archive queries only Verified Artwork records with `art_type = third-art-folio`. Before this data exists, show the approved archive holding state.

---

## 3. Elementor implementation rules

### Use native Elementor widgets
- Containers
- Heading
- Text Editor
- Image
- Image Gallery
- Button
- Icon / Icon List
- Divider
- Spacer only where necessary
- Video
- Accordion
- Tabs only when content structure truly needs tabs
- Loop Grid / Posts widgets if available in installed Elementor version, otherwise Elementor archive templates / native post widgets
- Form replacement: WPForms shortcode/widget integration only where supported by a native WPForms Elementor integration; do not use an HTML widget

### Do not use
- Inner Sections
- Atomic Elements
- Elementor HTML widgets
- Elementor Pro widgets
- fake repeated artwork cards
- direct checkout widgets for originals

### Novamira use
Use Novamira during build review to inspect, label and normalise Container hierarchy, widget usage, responsive structure and reusable Elementor element patterns. It must not be used to generate invented cultural content.

---

## 4. XPRO header and footer templates

### Header template — XPRO Library asset
**Name:** `Biya's Art Gallery | Global Header`

**Container structure**
1. Root header container — sticky behaviour configured in XPRO / Elementor settings.
2. Brand container: text logo “Biya's Art Gallery” and descriptor “Art | Poetry | Culture | Lahore”.
3. Desktop navigation container.
4. Collector CTA: Arrange a Private Viewing.
5. Mobile menu trigger / panel.

**Navigation**
- Home
- Artworks (Available Works, Collections, The Third Art, Archive / Sold Works, Gallery Artists)
- Biya Jee (Biography, Art and Installations, Poetry and Writing, Books and Library, Media and Interviews)
- Punjabi Verha (About, Monthly Events, Mushairas, Muqalma, Video Archive, Media Coverage, Join / Collaborate)
- Exhibitions and Events
- Projects and Interiors
- Commissions and Custom Studio
- Trade and Hospitality
- Media and Press
- Visit / Contact

### Footer template — XPRO Library asset
**Name:** `Biya's Art Gallery | Global Footer`

**Container structure**
1. Brand / cultural statement column.
2. Explore navigation column.
3. Collector services column.
4. Visit / approved contact column.
5. Legal / copyright / policy row.

Do not show placeholder phone, email, map or social links. Hide that container until verified data is entered.

---

## 5. Page implementation sequence

### Phase A — global system
1. Create Elementor global Site Settings.
2. Build header and footer with XPRO Containers.
3. Save both templates in XPRO Library.
4. Assign templates site-wide.
5. Create WordPress menu and menu hierarchy.
6. Create blank pages and assign final slugs.

### Phase B — approved core pages
| Page | Elementor sections |
|---|---|
| Home | Hero, brand statement, verified featured works / holding state, culture pillars, event holding state, private viewing CTA |
| Artworks | Archive hero, native filter / archive layout, verified cards or empty state |
| Artwork Single | Gallery, metadata, story, Request Price, request form, care, related verified works |
| Biya Jee | Hero, approved biography, practice, approved sources, CTA; show public name only Biya Jee |
| The Third Art | Approved proposition, process and archive holding state |
| Events | Verified event archive or holding state |
| Projects / Interiors | Rights-approved project cards or holding state |
| Commissions | Brief explanation, WPForms commission form, no binding price |
| Trade | Benefits, process, WPForms trade brief |
| Visit / Contact | Holding state until contacts confirmed; WPForms visit request can be prepared |

### Phase C — independent cultural pillars
- Punjabi Verha hub and related archive templates.
- Books / Library archive and item template.
- Media / Press archive.
- Journal archive and article template.

### Phase D — required utility pages
- Guide / FAQ
- Privacy
- Terms / Commission Policy / Delivery & Returns
- 404

---

## 6. WPForms plan

| Form | WPForms fields | Notification destination | Status |
|---|---|---|---|
| Request Price / Details | artwork, name, email, city, room context, timeline, consent | Awaiting owner-approved inbox / CRM | Build draft only |
| Private Viewing | name, contact, preferred date, interest, consent | Awaiting booking destination | Build draft only |
| Commission Brief | room type, size, art type, palette, budget comfort, timeline, upload, consent | Awaiting studio inbox | Build draft only |
| Trade Brief | company, project, rooms, dimensions, budget, install date, consent | Awaiting trade inbox | Build draft only |
| Event RSVP | event, name, contact, accessibility / notes, consent | Awaiting event inbox | Build after event data |
| Punjabi Verha collaboration | organisation, proposal, contact, consent | Awaiting coordinator | Build draft only |

All forms require spam protection, privacy consent, validation, thank-you copy and tested notification delivery before publication.

---

## 7. Empty-state implementation

Use native Elementor Containers with Heading, Text Editor and Button widgets.

- **Surah Rehman archive:** “This folio archive is being digitised with care. Individual folios will be published after image, source and rights review.”
- **Artwork archive:** “Selected works are being prepared for the gallery archive. Request a private conversation.”
- **Books / Library:** “The Biya Jee library is being catalogued.”
- **Punjabi Verha:** “Programme history, media and future gatherings are being assembled with source review.”
- **Contact:** no public contact details until supplied; show private-viewing request form only when notification destination works.

---

## 8. Redirect and migration plan

1. Build all final WordPress routes in staging.
2. Import only Verified content.
3. Set homepage to `/`.
4. Create 301 redirects from every current `.html` route.
5. Test every redirect for HTTP 301 and final canonical destination.
6. Retain a redirect inventory in Stage 3 launch report.

Key examples:
- `/index.html` → `/`
- `/collections.html` → `/artworks/`
- `/third-art.html` → `/artworks/the-third-art/`
- `/founder.html` → `/biya-jee/`
- `/events.html` → `/events/`
- `/custom-studio.html` → `/commissions/`
- `/b2b.html` → `/trade-hospitality/`

---

## 9. Publication checklist before connected-site deployment

- [ ] XPRO header and footer saved in library and assigned globally.
- [ ] Homepage configured in WordPress Settings > Reading.
- [ ] Menu created and assigned to header location.
- [ ] No Elementor HTML widgets, Pro widgets, Inner Sections or Atomic Elements.
- [ ] All forms use WPForms and tested destinations.
- [ ] No unverified founder name, archive, artwork or cultural claim published.
- [ ] No original-art checkout.
- [ ] No placeholder imagery presented as real art.
- [ ] 301 redirect test report passed.
- [ ] Stage 3 QA approval received.
