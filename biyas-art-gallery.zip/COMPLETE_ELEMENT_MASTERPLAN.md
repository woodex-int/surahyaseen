# Biya Gallery Art & Craft — Complete Element Masterplan

**Purpose:** exhaustive page, content, technical, commercial and launch element inventory.  
**Status key:** ✅ built · 🟡 built but needs real business data · 🔴 missing / not yet connected.

---

# A. Global website elements

| Element | Status | What is complete / what is missing |
|---|---:|---|
| Brand system | ✅ | Biya Gallery Art & Craft identity, evergreen / gold / espresso / champagne palette, editorial typography and motion rules are built. |
| Desktop header | ✅ | Consistent primary navigation and primary CTA across pages. |
| Mobile menu | ✅ | Responsive menu interaction is built. |
| Final navigation architecture | 🟡 | Nine top-level links are present. Final production should use a compact **More** menu for Poetry, Journal, Events, Visit and Guide. |
| Footer | ✅ | Brand, key links and guide link are present. |
| Official footer details | 🔴 | Add legal entity name, full address, phone, email, social links and copyright policy. |
| Search | 🔴 | Add search only after the catalogue has real work records. |
| Newsletter | 🟡 | Journal sign-up design is built; email delivery is not connected. |
| Cookie consent | 🔴 | Required if analytics, Meta Pixel or other tracking tools are used. |
| 404 page | 🔴 | Create branded not-found page before launch. |
| Accessibility controls | 🟡 | Keyboard focus and reduced motion exist; final alt text, form errors and live-device review remain. |

---

# B. Complete page inventory

## 1. Home page

### Built
- ✅ Cinematic brand opening using the Biya Gallery visual identity.
- ✅ Full-screen hero, hero title lockup and entry CTA.
- ✅ Scroll-driven “Not decoration. A presence.” scene.
- ✅ Thread Art / artist-hand scene.
- ✅ Selected works section.
- ✅ Poetry / literary practice scene.
- ✅ Biya Jee portrait and book / publication section.
- ✅ Services and private-viewing conversion section.
- ✅ Final inquiry CTA.

### Missing / to finalise
- 🟡 “Now showing” section once a real current collection exists.
- 🟡 One genuine featured work with title, medium, dimensions and availability.
- 🔴 Official contact / WhatsApp conversion in hero or footer.
- 🔴 Real selected artworks with final metadata instead of demonstration labels.
- 🔴 Optimised real gallery photography for all scene backgrounds.

---

## 2. Collection page

### Built
- ✅ Editorial collection hero.
- ✅ Filter controls: All, Original Art, Thread Art, Studies, Available toggle.
- ✅ Eight visual demo work cards.
- ✅ Quick-view artwork dialog.
- ✅ Inquiry CTA from each work.

### Missing / to finalise
- 🔴 Real artwork database / JSON / CMS source.
- 🔴 Artwork title, year, medium, dimensions, price and availability for every work.
- 🔴 Individual permanent artwork detail URLs.
- 🔴 Search, sort, pagination and saved wishlist for larger catalogue.
- 🔴 Sold archive and commission-reference filtering.
- 🔴 Artwork care, certificate, framing and delivery details.

---

## 3. Individual artwork-detail page

### Current status: 🔴 missing

### Required elements
- Breadcrumb.
- Full-image zoom gallery.
- Main full work, close-up detail, in-room photo and process photo.
- Artwork title, year, medium and dimensions.
- Availability and price / price-on-request.
- Artist statement / artwork story.
- Certificate of authenticity note.
- Framing, shipping and care accordion.
- “Inquire about this work” and WhatsApp CTA.
- Related works.
- SEO `VisualArtwork` structured data.

---

## 4. Founder / Biya Jee page

### Built
- ✅ Founder hero and real supplied portrait.
- ✅ Biographical narrative.
- ✅ Poet, fiction writer, artist and cultural leader positioning.
- ✅ Punjabi poetry archive link.
- ✅ Qasim Ali Shah Foundation interview source.
- ✅ Third Art / Thread Art narrative.
- ✅ Published source block.

### Missing / to finalise
- 🟡 Confirm official spelling of Naghmana Khursheed / Khurshid globally.
- 🔴 Official CV with education, appointments, awards, publications and exhibitions.
- 🔴 Names, covers, dates and ISBN / publisher data for the three Punjabi poetry collections.
- 🔴 Official portrait series / studio photography.
- 🔴 Approved first-person quote.
- 🔴 Verified press / media links.

---

## 5. Poetry page

### Built
- ✅ Poetry-led visual design.
- ✅ Direct Folk Punjab archive gateway.
- ✅ Four published work links.
- ✅ Cultural-collaboration CTA.

### Missing / to finalise
- 🔴 Books & Publications page / section.
- 🔴 Approved Urdu, Punjabi / Shahmukhi and English excerpts or translations.
- 🔴 Bibliography for three poetry collections.
- 🔴 Audio readings, reading-event recordings or author commentary (optional).
- 🔴 Rights confirmation before displaying full poems on-site.

---

## 6. The Third Art page

### Built
- ✅ Third Art proposition, process and language sections.
- ✅ Surah Rehman archive entry point.
- ✅ Research / attribution note.

### Missing / to finalise
- 🟡 Approved public definition of “The Third Art.”
- 🔴 Artist-approved movement statement and correct terminology.
- 🔴 Real portfolio of process / finished works.
- 🔴 Dated development timeline, exhibitions and press if applicable.
- 🔴 Complete source list / citations if historical or “first” claims are made.

---

## 7. Surah Rehman handmade archive

### Built
- ✅ 75% artwork viewer / 25% information rail.
- ✅ 70 folio navigation, active state and looped arrow logic.
- ✅ Main-image full-screen interaction.
- ✅ Keyboard navigation and Escape close.
- ✅ Selected-folio inquiry handoff.
- ✅ Internal rail scrolling; no main-page scroll jump.

### Missing / to finalise
- 🔴 Seventy separate, high-resolution source images.
- 🔴 Exact folio name / verse / section for each image, if appropriate.
- 🔴 Medium, dimensions, year and availability per folio.
- 🔴 Artist statement for the full handmade portfolio.
- 🔴 Optional recitation / audio / page-turn story layer.
- 🔴 Final portfolio credit and copyright guidance.

---

## 8. Services page

### Built
- ✅ Original Art service.
- ✅ Bespoke Commission service.
- ✅ Thread Art service.
- ✅ Culture & Curation service.
- ✅ Commission journey.
- ✅ Private inquiry experience.

### Missing / to finalise
- 🔴 Official commission lead times.
- 🔴 Official pricing / estimate policy.
- 🔴 Deposit and cancellation policy.
- 🔴 Delivery, installation, framing and international shipping scope.
- 🔴 Live contact routing.
- 🔴 Service-specific case studies and completed projects.

---

## 9. Visit / private viewing page

### Built
- ✅ Private-viewing hero.
- ✅ Three visit paths: viewing, advisory, studio / culture.
- ✅ What-to-expect journey.
- ✅ Appointment request form.

### Missing / to finalise
- 🔴 Address, map, parking / access note and appointment hours.
- 🔴 Phone, WhatsApp and email.
- 🔴 Live appointment scheduling or confirmation workflow.
- 🔴 Gallery / showroom photographs.
- 🔴 Accessibility information for the physical location.

---

## 10. Journal page

### Built
- ✅ Journal landing page.
- ✅ Thread Art, poetry and collecting content pathways.
- ✅ Published interview feature.
- ✅ Email-list design.

### Missing / to finalise
- 🔴 Real article publishing workflow.
- 🔴 Category / tag archive.
- 🔴 Journal entry detail template.
- 🔴 Author name, publish dates and approved cover imagery.
- 🔴 Newsletter delivery integration.

---

## 11. Events page

### Built
- ✅ Poetry, art and culture program categories.
- ✅ Event invitation / guest-list design.
- ✅ RSVP interaction UI.

### Missing / to finalise
- 🔴 Confirmed event calendar.
- 🔴 Event detail page with date, time, venue, guests and program.
- 🔴 Capacity management and live RSVP confirmation.
- 🔴 Calendar integration.
- 🔴 Event photography / recordings after events occur.

---

## 12. Collector & Commission Guide / FAQ

### Built
- ✅ Collecting, commissioning, visiting and cultural-partnership FAQs.
- ✅ Expandable accordion interactions.

### Missing / to finalise
- 🔴 Official business answers: payment, deposits, lead times, delivery, installation, care and returns.
- 🔴 International client / customs guidance if applicable.

---

# C. Missing high-priority pages

## 1. Contact & Showroom — 🔴 Priority 1
- Gallery address and map.
- Contact cards: WhatsApp, telephone, email.
- Opening / appointment hours.
- General inquiry form.
- Social links.
- “How to find us” instructions.
- Parking / building access note.

## 2. Custom Studio / Commission Brief — 🔴 Priority 1
- Select service / artwork type.
- Room upload or project brief.
- Wall dimensions.
- Material / medium preference.
- Palette / mood choice.
- Budget / deadline field.
- Automatically generated summary sent to gallery.
- Optional estimator only after rate approval.

## 3. Installations & Portfolio — 🔴 Priority 2
- Real residential, hospitality, office and cultural installation photographs.
- Project story, work title, city, scale and medium.
- “Create a similar feeling” commission CTA.

## 4. B2B / Trade portal — 🔴 Priority 2
- For designers, architects, hotels, restaurants, workplaces and cultural institutions.
- Trade enquiry form.
- Downloadable trade deck.
- Project curation process.
- Bulk / hospitality commission route.

## 5. Policies / legal center — 🔴 Priority 1 before checkout
- Privacy Policy.
- Terms of Use.
- Commission Terms.
- Shipping / Delivery policy.
- Returns / Cancellation policy.
- Artwork Care.
- Copyright / image-use notice.

## 6. 404 / Not Found page — 🔴 Priority 2
- Branded recovery page with collection and contact CTAs.

---

# D. Content inventory required from Biya Gallery

## Business identity
- [ ] Official business name.
- [ ] Legal / tax entity information, if relevant.
- [ ] WhatsApp number.
- [ ] Phone number.
- [ ] Email address.
- [ ] Physical address and Google Maps link.
- [ ] Opening hours / appointment policy.
- [ ] Official social profiles.

## Founder
- [ ] Correct spelling of name.
- [ ] Approved biography.
- [ ] CV and milestone timeline.
- [ ] Three poetry-book details and covers.
- [ ] Verified roles / titles and dates.
- [ ] Awards, exhibitions and press.
- [ ] Approved portrait pack.

## Artwork
- [ ] 12–20 launch artwork records.
- [ ] Full-resolution artwork images.
- [ ] Artwork metadata sheet.
- [ ] Availability and price approach.
- [ ] Commission reference approval.
- [ ] Surah Rehman 70-folio image set.

## Operations
- [ ] Payment methods.
- [ ] Delivery areas, delivery price and lead time.
- [ ] Commission terms and deposit policy.
- [ ] Framing and installation policy.
- [ ] Returns / cancellation policy.
- [ ] Customer response process.

---

# E. Data model required before live catalogue

## Artwork record
```text
id
slug
title
series
year
artist
medium
dimensions
edition
availability
price or price-on-request
short description
long story
main image
additional images
alt text
care notes
framing note
shipping note
related works
SEO title / description
```

## Event record
```text
id
title
date
time
venue
city
hosts / readers / artists
short description
cover image
capacity
RSVP method
accessibility / access note
```

## Inquiry record
```text
name
email
phone / WhatsApp
inquiry type
artwork / folio reference
message
budget range (optional)
timeline (optional)
status
consent timestamp
```

---

# F. Technical elements still missing

| Element | Status |
|---|---:|
| Live form endpoint | 🔴 |
| WhatsApp deep-link routing | 🔴 |
| Email / CRM integration | 🔴 |
| Spam protection | 🔴 |
| CMS or catalogue data source | 🔴 |
| Image optimisation / WebP / AVIF | 🔴 |
| Lazy loading / image dimensions | 🔴 |
| Sitemap.xml | 🔴 |
| Robots.txt | 🔴 |
| Canonical URLs | 🔴 |
| Analytics / consent | 🔴 |
| Search Console | 🔴 |
| 404 page | 🔴 |
| Live domain QA | 🔴 |
| Backup / versioning plan | 🔴 |

---

# G. Final navigation recommendation

## Primary desktop navigation
1. Gallery
2. Collection
3. Services
4. The Third Art
5. Biya Jee
6. **More**: Poetry, Journal, Events, Visit, Guide & FAQ
7. CTA: Start a Conversation

## Mobile navigation
All pages remain visible in a full-height menu, with Contact / WhatsApp fixed at the bottom once official contact information is supplied.

---

# H. Build order

## Sprint 1 — Trust and live contact
- Contact & Showroom page.
- Official contact information.
- Form delivery integration.
- Privacy / terms / commission / delivery pages.
- 404 page.

## Sprint 2 — Real catalogue
- Artwork data structure.
- Full artwork-detail pages.
- Replace demo works.
- Real Surah Rehman 70-folio archive.
- Collection filtering and availability logic.

## Sprint 3 — Commission and partnerships
- Custom Studio / Commission Brief.
- Installations & Portfolio.
- B2B / Trade page.
- Event detail / RSVP workflow.

## Sprint 4 — Publishing and growth
- Journal article templates.
- Books / Publications page.
- Bilingual content.
- SEO launch setup and live performance audit.

---

# Final launch definition

The site is fully launch-ready when all official contact information, real catalogue records, live form delivery, legal policy pages, artwork-detail pages, optimised images, SEO setup, mobile QA and approved founder / business facts have been completed.
