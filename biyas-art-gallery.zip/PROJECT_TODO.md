# Biya Gallery Art & Craft — Project To‑Do List

**Last updated:** 23 August 2026  
**Project status:** Design concept, core pages and Service experience complete. Content, commerce and production integration remain pending.

---

## ✅ Completed

### Brand & creative direction
- [x] Define luxury visual system: deep evergreen, espresso, rich gold and champagne paper.
- [x] Restore **Biya Gallery Art & Craft** naming in the global wordmark.
- [x] Build cinematic homepage hero using the supplied original gallery branding visual.
- [x] Create visual direction for original art, Thread Art, poetry and cultural programming.
- [x] Complete brand / audience / competitor / SEO / experience strategy document.

### Website pages
- [x] Homepage with cinematic hero, collection storytelling, selected works, Third Art feature and collector CTA.
- [x] Founder page for Naghmana Khursheed / Biya Jee.
- [x] Founder biography expanded: gallery founder, poet, fiction writer, Thread Artist, Chairperson of Punjabi Virsa, President of Arts & Culture.
- [x] Add Folk Punjab poetry source and Qasim Ali Shah Foundation interview source links.
- [x] The Third Art page with movement statement, visual language and interactive 70-tile archive.
- [x] Full-suite Services page: original art, bespoke commissions, Thread Art, culture and curation.
- [x] Redesigned private inquiry / commission form experience.

### Design system & motion
- [x] Responsive desktop and mobile layouts.
- [x] Header states, active navigation, premium CTA treatment and mobile navigation.
- [x] Scroll reveal choreography, gentle hero camera drift, parallax-style scenes and work-card hover states.
- [x] Reduced-motion support for accessibility.
- [x] High-contrast improvements for header, editorial green panels, forms and footer.
- [x] Generated supporting art-gallery, Thread Art and collector-salon visuals.

### SEO foundations
- [x] SEO title, meta description, Open Graph metadata and ProfessionalService schema on Services page.
- [x] Keyword-aligned services copy for Lahore / Pakistan art commissions, Thread Art and cultural curation.

---

## 🔴 Priority — Needed from Biya Gallery

### Official business information
- [ ] Confirm the official public brand spelling: **Biya Gallery Art & Craft** vs **Biya’s Art Gallery**.
- [ ] Confirm artist name spelling for all public copy: **Naghmana Khursheed** or **Naghmana Khurshid**.
- [ ] Provide gallery email address.
- [ ] Provide WhatsApp / phone number.
- [ ] Provide physical address, city, Google Maps URL and opening / appointment hours.
- [ ] Confirm areas served: Lahore only, Pakistan-wide, international or all three.
- [ ] Confirm official social-media URLs: Instagram, Facebook, YouTube, TikTok, Pinterest, LinkedIn if applicable.

### Founder facts and approvals
- [ ] Approve the Founder-page biography and titles exactly as published.
- [ ] Confirm full organisation name for **Punjabi Virsa**.
- [ ] Confirm full organisation / title for **President, Arts & Culture**.
- [ ] Provide dates, awards, exhibitions, books, organisations and notable press mentions for a verified CV.
- [ ] Provide an approved professional portrait of Biya Jee for the permanent founder image.
- [ ] Provide one approved founder quote, ideally 20–35 words.

### Artwork and catalogue
- [ ] Supply 12–20 launch artworks for the Collections page.
- [ ] Supply 70 unique images / work details for the Third Art archive; current archive uses visual placeholders.
- [ ] For every artwork, supply: title, year, medium, dimensions, edition if relevant, price / “price on request”, availability and story.
- [ ] Supply high-resolution images: full work, detail, installed-in-space and artist/process image where available.
- [ ] Confirm whether prices are public or inquiry-only.
- [ ] Confirm shipping, installation, framing and certificate-of-authenticity policy.

---

## 🟠 Next Development Sprint

### Collection and commerce
- [x] Build a Collections page with filters: Original Art, Thread Art, Studies and Available Works. *(Uses demonstrative works until real catalogue data is supplied.)*
- [x] Build an artwork-detail quick-view template with image, story, medium, availability and inquiry action. *(Add dimensions and final work records when supplied.)*
- [ ] Add “Request catalogue” download / email capture journey.
- [ ] Add a WhatsApp inquiry integration with prefilled artwork or commission details.
- [x] Add a private-viewing request page and appointment form. *(Form delivery integration remains pending.)*
- [ ] Decide payment path: enquiry-only, bank transfer, payment gateway or e-commerce checkout.

### Forms & communications
- [ ] Connect all inquiry forms to an email inbox, WhatsApp, CRM or form provider.
- [ ] Add automated “thank you” email and internal enquiry notification.
- [ ] Add privacy consent checkbox and privacy-policy link to all forms.
- [ ] Add a newsletter sign-up for new works, poetry and exhibition announcements.

### Content and storytelling
- [x] Create a Journal page for poetry, studio notes, cultural archive and collector guidance. *(Editorial entries are ready for expansion with approved exhibition dates and original articles.)*
- [x] Create a dedicated Poetry archive page linked to Folk Punjab and approved published work titles.
- [ ] Add a Visit / Appointments page with gallery experience, map, hours and contact channels.
- [x] Create Collector & Commission Guide / FAQ page covering collecting, private viewings, Thread Art, commissions and cultural collaborations. *(Add official lead times, pricing ranges and delivery policy when confirmed.)*
- [ ] Add testimonials / collector stories only after written permission is received.

---

## 🟡 Production Quality & SEO

- [ ] Add unique SEO title and meta description to Home, Founder and Third Art pages.
- [ ] Add Organization, LocalBusiness, Person and VisualArtwork schema once confirmed data is available.
- [ ] Add canonical URLs, `sitemap.xml`, `robots.txt` and Google Search Console verification after domain launch.
- [ ] Add meaningful alt text to every production artwork image.
- [ ] Convert final artwork imagery to WebP / AVIF and define image sizes for faster loading.
- [ ] Add image lazy-loading below the hero.
- [ ] Check all external links, mobile navigation and form submissions before launch.
- [ ] Run Lighthouse performance, accessibility, best-practices and SEO checks.
- [ ] Add cookie / analytics consent if Meta Pixel, Google Analytics or similar tracking is enabled.
- [ ] Add Privacy Policy, Terms, Commission Terms, Shipping / Returns and Copyright pages.

---

## 🟢 Nice-to-have — Future Experience Enhancements

- [ ] Add an interactive room-scale / “view on wall” art preview.
- [ ] Add multilingual support: English, Urdu and Shahmukhi Punjabi.
- [ ] Add virtual private viewing via video call booking.
- [ ] Add a curated collector account / wishlist.
- [x] Build an Events page and invitation / guest-list RSVP experience. *(Add confirmed programs, dates and venue details when announced.)*
- [ ] Add an exhibition timeline once the first confirmed calendar is supplied.
- [ ] Add a low-bandwidth virtual gallery tour after the real artwork catalogue is ready.
- [ ] Build a password-protected trade / interior-designer portal.

---

## Launch Definition of Done

The website is launch-ready when the official contact information, approved brand and founder facts, first artwork catalogue, form integration, legal pages, mobile QA, SEO setup and image optimisation are all complete.
