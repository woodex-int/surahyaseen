# Project Start — Stage 1 Only

## Authorised work
Create planning, source-verification and archive-content documentation. Normalise project identity and record all missing material.

## Not authorised
- No HTML, CSS, JavaScript, WordPress, routing or production content edits.
- No invented biography, catalogue, archive, event, book, policy, pricing or cultural claims.

## Stage 1 completion test
Stage 1 is complete only when every planned published claim is labelled **Verified**, **Pending Verification** or **Not for Publication**; Punjabi Verha and Books / Library have independent content structures; and Agent 02 receives a clear source-approved handoff.

## Owner inputs required
1. Official founder English spelling.
2. Real 70-folio images and metadata.
3. Book-library data for 20+ titles.
4. Punjabi Verha event, video and press archive.
5. Approved artwork, collection, exhibition and project records.
6. Business contacts, policies and rights approvals.
