# Biya's Art Gallery — Deep WordPress / Elementor / XPRO Audit & Master Recovery Plan

**Audit date:** 23 August 2026  
**Audit basis:** project source files, WordPress deployment packages, Stage 1–3 governance documents, package source code, and supplied connected-site screenshots.  
**Audit limitation:** no authenticated administrative or server access was supplied. Plugin versions, active theme, PHP/WP error logs, database meta, actual XPRO library records, form mail delivery, menu assignment and redirects must be verified in the target site before go-live.

## Executive status

**Current condition: BUILD RECOVERY / NOT READY TO PUBLISH.**

The WordPress site has pages and Elementor content rendering, which is progress. It is not a completed gallery website yet. The screenshots show an early starter Home layout with a default page title, unstyled/invisible CTA links, default theme footer output, and no evidence of an assigned XPRO header or footer. Current published pages should be treated as pre-production drafts until reviewed.

The governing content rules remain correct: only Verified, rights-approved records may publish; public founder label remains **Biya Jee**; originals and Third Art folios are enquiry-only; and Surah Rehman remains a holding archive until approved Artwork folio records exist.

---

# 1. Evidence reviewed

## 1.1 Connected-site screenshots
Observed:
- Pages were created and many were published.
- A Home layout renders title, descriptor and two CTA labels, proving some Elementor data is present.
- The native page title “Home” remains visible above the intended layout.
- CTA labels are very low-contrast on champagne, making them effectively inaccessible.
- The visible “All rights reserved” footer is default-theme output, not the approved XPRO footer.
- No working navigation/header is visible.

## 1.2 Deployment artifacts reviewed
- Hello Elementor child master theme package.
- Optional brand child package.
- CPT / taxonomy plugin.
- ACF JSON package.
- Generic Elementor JSON package.
- Elementor Installer plugin.
- XPRO manual template package.

## 1.3 Governance and source records reviewed
- Stage 1 source / verification controls.
- Stage 2 template and data architecture.
- Stage 3 QA handoff.
- Final navigation requirement.

---

# 2. Audit findings

| ID | Priority | Finding | Evidence / risk | Required fix |
|---|---|---|---|---|
| P0-01 | Critical | Incomplete pages are published. | Screenshot shows published pages, while site layout/content is not approved. | Change unfinished pages to Draft or Private; retain URLs for redirect review. |
| P0-02 | Critical | Global XPRO Header/Footer is not assigned. | Default page title and default footer are rendering. | Build Header and Footer through XPRO Theme Builder, assign Entire Site display conditions, then save both to XPRO Library. |
| P0-03 | Critical | Homepage lacks finished Container visual system. | Only a minimal intro/CTA block is shown. | Implement approved Home master layout with global design tokens and holding-state modules. |
| P0-04 | Critical | Generic JSON import is not a reliable live build strategy. | Earlier import created pages but did not yield a complete editable design system. | Use Elementor Installer plugin only to create draft starting layouts; complete the actual layouts in the target Elementor/XPRO UI. |
| P0-05 | Critical | Content publication controls are not enforced by plugin code. | CPT plugin registers types but does not block Pending / unverified content from public archives. | Add a dedicated governance plugin / query controls before dynamic archives launch. |
| P1-01 | High | CTA contrast and button styling fails. | White / near-white links are illegible against the champagne background. | Define Elementor Global Buttons and apply evergreen fill, champagne text and gold focus border; verify WCAG contrast. |
| P1-02 | High | Native page title is duplicated. | “Home” appears above intended hero. | Set each Elementor page to Elementor Full Width / Canvas as appropriate and disable page title in theme/page settings. |
| P1-03 | High | Header navigation is unbuilt/unassigned. | No navigation present in supplied Home preview. | Create WordPress menu, then configure it in the XPRO Header. |
| P1-04 | High | WPForms pathways are not configured. | CTA targets are placeholders. | Create, test and connect Request Price, Viewing, Commission, Trade, RSVP and Contact forms. |
| P1-05 | High | WhatsApp number is not verified. | No official number provided. | Keep widget disabled until owner adds approved international number. |
| P1-06 | High | ACF configuration is incomplete for governance enforcement. | JSON provides fields but conditional behaviour and front-end querying require target-site validation. | Import fields, validate locations, make Event Type and folio fields required, then enter test records. |
| P1-07 | High | Event type is not truly required yet. | Taxonomy terms are seeded but WordPress allows an Event without a term. | Add editor-side validation: every Event and Punjabi Verha Event must have exactly one approved `event_type`. |
| P1-08 | High | Third Art archive safety is not implemented in a live archive query. | Data model exists but query/template does not. | Create a dedicated archive source constrained to Artwork + `art_type=third-art-folio` + Verified only; otherwise show holding state. |
| P2-01 | Medium | Theme package layering is unnecessarily confusing. | Main child theme, optional child and duplicated `template.zip` / `themle.zip`. | Use one active theme only: Hello Elementor + `theme.zip`. Archive / remove optional packages from normal install instructions. |
| P2-02 | Medium | Dynamic single/archive templates are absent. | Pages are starter layouts rather than CPT templates. | Build Elementor/XPRO or theme-level templates for Artwork, Event, Collection and archives after data validation. |
| P2-03 | Medium | No evidence of SEO, caching, backup, security or accessibility configuration. | Not auditable from screenshot. | Complete technical go-live audit before publication. |
| P2-04 | Medium | 301 redirect deployment not shown. | Legacy static URLs still need mapping/testing. | Configure redirect plugin/server rules and test every legacy `.html` route for 301. |

---

# 3. Technical decisions — locked for recovery

## Builder and theme
- Active base: **Hello Elementor**.
- Active gallery theme: **Biya's Art Gallery Master (`theme.zip`)** only.
- Build layouts with **Containers** only.
- Use native Elementor widgets wherever possible.
- Do not use HTML widgets, Inner Sections, Atomic Elements or Elementor Pro widgets.
- XPRO is permitted for global Header/Footer placement and its own non-Pro components.
- WPForms owns all enquiry and contact forms.
- Novamira is used for structure review and organisation, never to invent content.

## Data model
- Third Art folios are `Artwork` posts, filtered by `art_type=third-art-folio`.
- `artist_profile` is an ACF Post Object / Relationship field to Artist CPT. No artist taxonomy.
- `artwork_collection` is the Artwork collection taxonomy.
- Required Event types: exhibition, mushaira, muqalma, talk, private-viewing, other.

---

# 4. Master recovery plan

## Phase 0 — Stabilise the live environment (before visual work)
**Owner:** WordPress administrator  
**Exit condition:** safe working environment.

1. Create full database/files backup and restore point.
2. Record WordPress, PHP, Elementor, XPRO, WPForms, ACF and Novamira versions.
3. Confirm Hello Elementor and `theme.zip` are active; do not activate `child.zip`.
4. Set every unfinished published page to Draft or Private.
5. Confirm no generated/reference/placeholder images are publicly presented as genuine art.
6. Keep WhatsApp widget disabled.
7. Create a staging copy if the current connected site is public.

## Phase 1 — Build the global foundation
**Owner:** Elementor/XPRO implementer  
**Exit condition:** one polished global shell applies across test pages.

1. Elementor → Site Settings:
   - Colours: Evergreen `#122622`, Espresso `#18130E`, Gold `#C9A54D`, Champagne `#F7F1E5`.
   - Container width: 1280px.
   - Desktop / mobile gutters: 32px / 20px.
   - Define typography and Global Buttons.
2. Fix the button contrast failure.
3. Create a WordPress menu using final navigation.
4. Build **Biya's Art Gallery | Global Header** in XPRO:
   - Brand and descriptor;
   - XPRO/WordPress menu;
   - Private Viewing CTA;
   - responsive mobile disclosure menu;
   - entire-site condition.
5. Build **Biya's Art Gallery | Global Footer** in XPRO:
   - brand statement;
   - explore links;
   - collector services;
   - legal row;
   - hide contact/social data until verified;
   - entire-site condition.
6. Save both into XPRO Library.
7. Remove/disable the default theme footer and duplicate page title on Elementor pages.

## Phase 2 — Home as the approved visual master
**Owner:** Elementor implementer + content owner  
**Exit condition:** approved Home design has only governed content.

Create these native Container sections:
1. Hero: brand, descriptor, approved positioning, two visible CTAs.
2. Editorial introduction: approved brand language only.
3. Three cultural pillars: Artworks, Biya Jee, Punjabi Verha.
4. Featured Artworks: verified dynamic source or neutral holding state.
5. Third Art: approved statement plus archive holding state.
6. Events: verified source or holding state.
7. Collector conversion section: WPForms-dependent CTAs.

No invented artist profile, artwork, folio, event, phone number or social account may be entered.

## Phase 3 — Content model and content operations
**Owner:** WordPress administrator / editor  
**Exit condition:** test content satisfies all schema rules.

1. Activate `content-model-plugin.zip`.
2. Install ACF and import `acf-json.zip`.
3. Validate all ACF fields / field locations in WP Admin.
4. Add validation rules for required Event Type and Third Art fields.
5. Create one non-public test record for each CPT.
6. Test `artist_profile` relationship from Artwork to Artist.
7. Test verification status workflow:
   - Verified = eligible for frontend;
   - Pending Verification = hidden / draft;
   - Not for Publication = blocked.

## Phase 4 — Build reusable template families
**Owner:** Elementor/XPRO implementer  
**Exit condition:** all families work with empty and verified test data.

Order:
1. Artwork archive and Artwork single.
2. Collection archive / single.
3. The Third Art controlled archive.
4. Biya Jee / poetry / library / media pages.
5. Events and Punjabi Verha event views.
6. Projects / interiors.
7. Commissions and Trade pages.
8. Press, Journal, Guide, Privacy, Terms and 404.

Every archive requires a deliberately designed empty/holding state.

## Phase 5 — Forms, enquiries and WhatsApp
**Owner:** administrator + owner  
**Exit condition:** every conversion path sends tested mail.

1. Create WPForms: Request Price, Private Viewing, Commission Brief, Trade Brief, Event RSVP, Contact.
2. Configure an owner-approved email/CRM destination.
3. Enable spam prevention, consent wording, validation and thank-you routes.
4. Test every form in production-like conditions.
5. Only after owner provides the official number, add it to Theme Customizer and test WhatsApp on desktop/mobile.

## Phase 6 — Page configuration, redirects and QA
**Owner:** launch manager  
**Exit condition:** ready for controlled publication.

1. Assign final slugs, parents and menu routes.
2. Set Home as static homepage only after Home approval.
3. Implement all static `.html` 301 redirects.
4. Test redirect status / final routes.
5. Test responsive views, keyboard navigation, focus states, image alt text, contrast, forms, 404 and search / sharing metadata.
6. Test artwork enquiry-only restrictions.
7. Publish Verified content only.

---

# 5. First three actions to take now

1. **Stop publishing unfinished pages:** make the current generated Pages Draft or Private.
2. **Build the XPRO global Header/Footer:** this is why the current Home has default output and no navigation.
3. **Apply Elementor Site Settings:** fix the visible white-on-champagne CTA contrast before adding more page sections.

---

# 6. Definition of done

The website is complete only when all items pass:

- [ ] Header/Footer work globally through XPRO and are saved in XPRO Library.
- [ ] A clean navigation and mobile menu work on every page.
- [ ] No duplicate native page title or default footer output remains.
- [ ] Every published page contains intentional Elementor Container content.
- [ ] Original artwork and Third Art are enquiry-only.
- [ ] Verified-only publishing controls are working.
- [ ] Event Type is required and validated.
- [ ] Third Art archive cannot expose unapproved folios.
- [ ] WPForms notifications are tested.
- [ ] WhatsApp is enabled only with approved number.
- [ ] All legacy static links return tested 301 redirects.
- [ ] Accessibility, responsive, SEO and launch QA pass.
