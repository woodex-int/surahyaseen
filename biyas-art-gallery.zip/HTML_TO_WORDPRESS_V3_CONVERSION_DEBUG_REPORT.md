# Biya’s Art Gallery — Legacy HTML → WordPress V3 Conversion Debug Report

**Audit date:** 23 August 2026  
**Source audited:** `index.html`, `style.css`, `app.js`, local asset references and the V3 reference Home template.  
**Purpose:** explain why the supplied legacy HTML does not convert one-to-one into the current V3 WordPress/OCDI draft package, identify technical/content defects, and define the correct conversion route.

## Executive finding

**This is not one bug. It is a source-to-governed-template mismatch.**

The legacy `biyas-art-gallery/index.html` is a visually rich bespoke static experience. The V3 package is a governed, media-free WordPress/Elementor draft foundation. The conversion intentionally removed legacy generated media, unverified text, invented archive records and unsupported bespoke interactions. That is why the V3 Home template appears simpler than the legacy HTML preview.

The screenshot is a valid display of the V3 HTML reference Home design. It is not evidence that the complete legacy cinematic page has been converted into Elementor/XPRO yet.

## 1. Static test results

| Test | Result |
|---|---|
| Legacy `app.js` syntax (`node --check`) | Pass |
| Legacy local asset path check | Pass: 21 referenced local files found |
| V3 Home reference HTML loads visual CSS structure | Pass by supplied preview screenshot |
| Legacy visual/content governance review | Fail — multiple prohibited/unverified legacy elements |
| One-to-one Elementor conversion | Not complete — only the V3 governed structural foundation is present |

## 2. Conversion blockers in legacy `index.html`

### C-01 — Prohibited outdated brand label
**Severity:** Critical

Legacy source includes:

```html
<strong>Creative Content</strong>
```

This directly conflicts with the project requirement: **do not use the label “Creative Content.”**

**Fix:** remove permanently. Use only:

```text
Biya’s Art Gallery
Art | Poetry | Culture | Lahore
```

### C-02 — Legacy identity conflicts
**Severity:** Critical

Legacy source uses:

```text
BIYA GALLERY
Art & Craft
Biya Gallery Art & Craft
```

The approved identity is:

```text
Biya’s Art Gallery
Art | Poetry | Culture | Lahore
```

**Fix:** do not migrate legacy header/footer identity strings to V3.

### C-03 — Public founder naming/content governance conflict
**Severity:** Critical

Legacy Home contains a public full-name reference and unsupplied biographical claims, including:

```text
Biya Jee · Naghmana Khursheed
Punjabi poet, social worker and columnist
three collections of Punjabi poetry
```

The project rule permits only **Biya Jee** on the public frontend until official spelling/full-name approval and documented claim verification exist.

**Fix:** migrate only `Biya Jee` label and approved source-backed copy. Keep full name/verification in admin-only content fields.

### C-04 — Generated hero imagery cannot become gallery artwork media
**Severity:** Critical

Legacy hero uses:

```text
assets/slide-gallery.png
assets/slide-exhibition.png
assets/slide-calligraphy.png
```

These were generated visual assets. They must not be published as real gallery artwork, exhibition or archive records.

**Fix:** V3 uses a text-only editorial hero/slider until rights-approved media is supplied.

### C-05 — Fabricated Surah Rehman archive interaction
**Severity:** Critical

Legacy `app.js` creates 70 apparent folios by changing background position on one image:

```js
for(let i=0;i<70;i++) { ... }
```

It labels them as:

```text
Folio 01 … Folio 70
Handcrafted calligraphy study
```

This violates the governing record: these are not 70 supplied distinct folio files and may not be published as independent folios.

**Fix:** do not convert this script to WordPress. V3 Third Art archive remains a holding state until distinct approved Artwork CPT folio records exist.

### C-06 — Placeholder/sample artwork titles and programme claims
**Severity:** High

Legacy source includes titles and descriptions such as:

```text
Language of Light
The Flower Remembers
After the Verse
Exhibitions, salon conversations and Mehfil moments
```

These are not confirmed Verified gallery records.

**Fix:** do not import as Artwork, Event, Collection, Press or Project data. V3 uses holding states.

### C-07 — Navigation does not match final V3 architecture
**Severity:** High

Legacy navigation is Gallery / Collection / More with links including Shop & Collection, Custom Studio, Interior Gallery and The Third Art Exhibition. The approved V3 route structure is broader and separates Artworks, Biya Jee, Punjabi Verha, Events, Projects, Commissions, Trade, Press and Visit.

**Fix:** use the V3 menu map; do not copy legacy nav one-to-one.

## 3. Legacy JavaScript defects

### J-01 — Hero slider timer can multiply
**Severity:** Medium

`app.js` starts a timer, clears it on mouse enter, then starts a new timer every mouse leave. Multiple consecutive mouse-leave events can create parallel intervals because the existing interval is not always cleared before a new one is assigned.

**Fix for any future approved slider:** always clear the existing interval before assigning a new one; add keyboard controls, pause state, focus handling and reduced-motion support. The V3 text-only slider plugin already provides a separate safer base.

### J-02 — Hero copy assumes all target elements exist
**Severity:** Medium

The legacy slider updates `#heroKicker`, `#heroHeading`, `#heroDescription` and `#heroSlideLabel` without null guards when hero slides exist.

**Fix:** guard all target elements or scope the slider only to a validated hero component.

### J-03 — Static HTML injection is not an Elementor strategy
**Severity:** High

The static app relies on complex CSS class choreography, background-image sections and JavaScript-generated tiles. Elementor Free / XPRO conversion must be component-based, not a copied HTML/JS blob or HTML widget.

**Fix:** translate only approved visual structures to Containers and native widgets; use a purpose-built optional slider plugin for the approved text-only sequence.

## 4. Legacy CSS/content risks

| Finding | Effect | V3 action |
|---|---|---|
| Remote Google Fonts `@import` | Remote font dependency | Use approved local/system typography or configure fonts in Elementor/XPRO after approval. |
| Repeated asset-based artwork cards | May represent supplied/unsupplied files as catalogue records | Do not auto-create Artwork posts. |
| Hero/portfolio image claims | Rights/attribution unknown | Keep out of public V3 import until cleared. |
| Real interview/book/portrait references | May require rights/verification and careful captions | Treat as Pending Verification, not default demo content. |
| Direct forms in static HTML | Not WPForms | Rebuild as WPForms after approved notification destination is supplied. |

## 5. Why the V3 template appears “empty” compared with legacy HTML

The legacy source contains many visual sections because it uses images and unverified editorial text. The V3 package deliberately starts with:

- Approved identity and descriptor
- Text-only editorial hero
- Holding-state modules
- Enquiry CTA paths
- No invented catalogue/event/archive records
- No AI/generated visual presented as real art

This is correct governance behaviour, but it means V3 is a **safe visual/system foundation**, not a pixel-for-pixel migration of the legacy homepage.

## 6. Correct conversion map

| Legacy feature | V3 conversion decision |
|---|---|
| Three generated image hero slides | Replace with V3 text-only slider or approved media carousel later |
| `Creative Content` lockup | Delete |
| Art & Craft branding | Replace with Biya’s Art Gallery identity |
| 70 cropped Surah tiles | Delete; use Third Art holding state |
| Static Collection artwork cards | Convert to dynamic Verified Artwork CPT cards only after records exist |
| Poetry scene | Convert to Biya Jee / Poetry & Writing route with approved external sources |
| Founder section | Use Biya Jee only; no full-name public reference until verified |
| Event/programme scene | Convert to Event CPT archive, blank/holding state until verified events exist |
| Contact forms | Rebuild as WPForms |
| Header/footer | Build with XPRO from V3 source maps; no default static header/footer copy |

## 7. Required V3 conversion work remaining

1. Build full V3 Elementor Containers from approved sections of the HTML reference, not from prohibited legacy content.
2. Build/assign XPRO Header and Footer in the target site.
3. Activate the Master Plugin and test governed CPT fields/queries.
4. Add WPForms and tested notification destinations.
5. Replace holding modules only when verified assets/records are supplied.
6. Do not migrate the old 70-folio JavaScript archive.
7. Perform clean staging OCDI/Elementor/XPRO validation before publication.

## Final conversion status

**Legacy static homepage visual preview:** working as a static file.  
**Legacy content safe for automatic WordPress migration:** no.  
**V3 governed theme/source package:** structurally built, but awaiting runtime WordPress testing and verified content.  
**Production publication approval:** not granted.
