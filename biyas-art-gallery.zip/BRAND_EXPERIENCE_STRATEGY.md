# Biya Gallery Art & Craft — Brand, Audience & Experience Strategy

## Brand read
Biya Gallery Art & Craft is strongest when it is not positioned as a generic décor shop or a conventional white-cube gallery. It is an author-led cultural house: **art, Punjabi poetry, Thread Art and craft** connected through Biya Jee’s voice.

**Distinctive equity**
- A founder with multiple authentic practices: poet, fiction writer, visual / Thread artist and cultural leader.
- A gallery identity that can unite work, language, cultural programming and collector relationships.
- The original *Biya Gallery Art & Craft* mark has a cinematic gallery-world sensibility and should remain a signature asset, not be replaced by a generic wordmark.

**Recommended positioning**
> A Lahore-based art and culture house where original work, poetry and hand-led craft become lasting presence.

## Audience
| Audience | Need | Website job |
|---|---|---|
| Emerging collector | Confidence, story, an approachable first purchase | Explain works clearly; make private enquiry feel welcoming. |
| Design-conscious homeowner | A piece that belongs to a specific room | Lead to commissions with scale, palette and process guidance. |
| Hospitality / workplace / interior professional | A memorable, reliable art partner | Surface bespoke briefs, curation and delivery / installation readiness. |
| Literary and cultural audience | A deeper relationship to Punjabi language and heritage | Give poetry, events and cultural collaborations their own space. |
| Diaspora collector | A trusted way to connect with Pakistani art remotely | High-resolution work details, provenance, virtual appointment and international inquiry. |

## Competitive context
The Lahore / Pakistan market includes established physical galleries and broad online art platforms. Ejaz Art Gallery presents itself as a large private Lahore gallery; Muse describes itself as a contemporary Lahore destination; Hunar positions as a curated online marketplace for Pakistani art. Their public propositions emphasise curated collections, buying art online, exhibitions, delivery and artist access. [Ejaz](https://ejazartgallery.com/) · [Muse](https://www.musegalleries.com/) · [Hunar](https://hunarartgallery.com/)

**Opportunity for Biya Gallery:** do not imitate a marketplace. Own the intersection of **the artist’s hand + literary voice + Thread Art + cultural hospitality**. The site should feel like entering Biya Jee’s world, then make the next step (collect, commission, collaborate) simple.

## Goals
1. Establish the gallery as a premium, author-led cultural brand.
2. Convert high-intent visitors into private inquiries and commissions.
3. Build a durable archive for works, poetry and The Third Art.
4. Give partners a credible path to exhibitions and cultural collaborations.
5. Make the founder’s multidimensional practice legible without overclaiming.

## Visual identity
- **Evergreen:** cultural depth, calm, craft.
- **Espresso:** gallery intimacy and cinematic negative space.
- **Rich gold:** attention, invitation and craft detail—not a decorative overuse.
- **Champagne paper:** editorial warmth and reading comfort.
- **Photography:** real work, material macro, gallery light, artist portrait and process. Avoid stock living rooms, generic paintbrush flat-lays and overproduced AI portraiture.
- **Type:** high-contrast editorial serif + restrained modern utility type. Poetry and artwork titles can breathe; interface copy must remain quiet.

## Experience / motion direction
### Opening scene
A dark corridor places the original Biya Gallery mark in view immediately. Value copy sits lower-left. A slow 6% push gives camera depth; it must never delay access to navigation or content.

### Scroll rhythm
1. **Threshold:** brand mark and gallery scene.
2. **Point of view:** the work is a presence, not a product.
3. **Encounter:** selected works appear like a physical hang.
4. **Practice:** Thread Art / Third Art explains distinction.
5. **Invitation:** collector or commissioner chooses a path.

### Motion rules
- One principal movement per viewport; no competing effects.
- 450–800ms interface transitions, 900–1200ms editorial reveals.
- Use translate and opacity for smooth rendering; never animate layout properties.
- Parallax is capped at 4–6% and disabled for `prefers-reduced-motion`.
- Hover adds information or confidence (lift, preview, CTA state); it should not merely decorate.
- No particle system in the production build unless it is a low-density canvas layer, pauseable, and absent on mobile / reduced motion. Ambient grain already offers the desired atmosphere at negligible cost.

## SEO plan
**Primary service themes:** art gallery services Lahore, original Pakistani art, custom art commissions Pakistan, Thread Art Pakistan, Punjabi art and culture, art advisory Lahore.

**Content clusters**
- Gallery: original art / collection pages with medium, year, dimensions, availability, alt text.
- Services: commission process, Thread Art, cultural curation, private advisory.
- Founder: sourced biography, poetry and interview links.
- Journal: poetry notes, studio process, exhibition previews, collector guides.

**Technical essentials**
- Unique title and description on every page; services page is already supplied with both.
- Add real `Organization`, `LocalBusiness`, `Person` and individual `Product` / `VisualArtwork` schema once contact/address/work data is confirmed.
- Generate sitemap.xml, robots.txt and canonical URLs on launch.
- Export final imagery in WebP/AVIF, set width/height, and use lazy loading beneath the hero.

## Content still required
- Approved phone, WhatsApp, email, gallery location and hours.
- 12–20 artwork records to launch collections; then 70 unique archive works.
- Official title / dates for Punjabi Virsa and Arts & Culture roles.
- Approved founder portrait and a signed first-person quote.
- Commission lead times, shipping territories, payment / return policy and install capability.
