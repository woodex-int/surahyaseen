# Biya’s Art Gallery — HTML Page, Section Count & V3 Conversion Audit

**Audit date:** 23 August 2026  
**Sources counted:** legacy static HTML in `biyas-art-gallery/` and V3 HTML references in `assad-complete/03-template-html-reference/`.  
**Method:** static parse of `<section>` elements and page files. Header/footer markup is not counted as a section unless it appears inside a `<section>` element.

## 1. Count summary

| Measure | Count |
|---|---:|
| Legacy static HTML pages | 15 |
| Legacy static `<section>` elements | 67 |
| V3 HTML reference pages | 33 |
| V3 HTML reference `<section>` elements | 67 |
| V3 reusable CSS design-system file | 1 |
| V3 Elementor JSON source templates | 33 |
| V3 WXR draft import records | 33 |
| V3 WXR draft pages | 31 |
| V3 WXR draft Elementor source templates | 2 |

## 2. Legacy static HTML page and section inventory

| Legacy page | Sections | Legacy section classes / IDs | V3 destination |
|---|---:|---|---|
| `index.html` | 8 | cinema hero, opening scene, craft scene, collection reveal, poetry scene, portrait scene, services drift, final CTA | `home.html` |
| `collections.html` | 4 | collection hero, toolbar, catalogue, note | `artworks.html`, `collections.html`, `archive-sold-works.html` |
| `custom-studio.html` | 2 | studio hero, brief | `commissions.html` |
| `gallery.html` | 2 | project hero, portfolio grid | `projects.html` |
| `third-art.html` | 6 | hero, premise, art language, archive, quote, research | `third-art.html` |
| `founder.html` | 7 | founder hero, bio, poetry, process, timeline, sources, contact | `biya-jee.html`, `poetry-writing.html`, `media-interviews.html` |
| `poetry.html` | 5 | poetry hero, intro, poem index, note, contact | `poetry-writing.html` |
| `events.html` | 5 | events hero, intro, programme, future programme, RSVP | `events.html`, `event-single.html`, Punjabi Verha routes |
| `portfolio.html` | 4 | portfolio hero, intro, grid, CTA | `projects.html`, `project-single.html` |
| `product.html` | 1 | product detail | `artwork-single.html` |
| `b2b.html` | 3 | trade hero, trade section, trade brief | `trade.html` |
| `journal.html` | 5 | journal hero, feature, list, video, signup | `journal.html` |
| `visit.html` | 5 | visit hero, intro, options, ritual, appointment | `visit-contact.html` |
| `faq.html` | 4 | FAQ hero, guide, FAQ area, final CTA | `guide.html` |
| `services.html` | 6 | services hero, intro, list, commission, proof, contact | `commissions.html`, `trade.html` |

**Legacy total:** 15 pages / 67 sections.

## 3. V3 HTML reference page and section inventory

### Core routes

| V3 reference page | Sections | Purpose |
|---|---:|---|
| `home.html` | 3 | Home hero, cultural pillars, holding state |
| `artworks.html` | 2 | Artwork archive foundation |
| `artwork-single.html` | 2 | Artwork enquiry-only single foundation |
| `archive-sold-works.html` | 2 | Historic/sold archive holding foundation |
| `collections.html` | 2 | Collection archive |
| `collection-single.html` | 2 | Collection single |
| `artist-single.html` | 2 | Artist profile single |
| `third-art.html` | 2 | Third Art controlled holding archive |
| `biya-jee.html` | 2 | Biya Jee public profile |
| `poetry-writing.html` | 2 | Poetry/writing route |
| `media-interviews.html` | 2 | Media/interviews route |
| `punjabi-verha.html` | 2 | Punjabi Verha hub |
| `punjabi-verha-events.html` | 2 | Punjabi Verha event archive |
| `mushairas.html` | 2 | Mushaira archive |
| `muqalma.html` | 2 | Muqalma archive |
| `video-archive.html` | 2 | Video archive holding state |
| `events.html` | 2 | General event archive |
| `event-single.html` | 2 | Event single |
| `projects.html` | 2 | Projects archive |
| `project-single.html` | 2 | Project single |
| `books.html` | 2 | Book archive |
| `book-single.html` | 2 | Book single |
| `press.html` | 2 | Press archive |
| `journal.html` | 2 | Journal archive |
| `commissions.html` | 2 | Commission route |
| `trade.html` | 2 | Trade/hospitality route |
| `visit-contact.html` | 2 | Visit/contact route |
| `guide.html` | 2 | Guide/FAQ route |
| `privacy.html` | 2 | Privacy route |
| `terms.html` | 2 | Terms/policy route |
| `404.html` | 2 | Recovery route |

### Global sources

| V3 source page | Sections | Purpose |
|---|---:|---|
| `header.html` | 2 | Header reference source — not a route page |
| `footer.html` | 2 | Footer reference source — not a route page |

**V3 total:** 33 reference files / 67 sections.

## 4. Conversion coverage result

### Page-route conversion

| Conversion measure | Result |
|---|---|
| Legacy pages mapped to an approved V3 route/family | 15 of 15 — 100% conceptual route coverage |
| New V3 route/reference pages beyond legacy scope | 18 additional files |
| Header/footer reference coverage | Present |
| Elementor source coverage | 33 JSON source files, one per V3 reference/template family |
| OCDI draft source coverage | 31 route pages plus 2 global source templates |

### Section conversion

| Measure | Result |
|---|---|
| Legacy section quantity | 67 |
| V3 reference section quantity | 67 |
| Numeric section parity | Yes — 67 vs 67 |
| Pixel-for-pixel legacy conversion | No |
| Governed functional conversion | Partial — source templates exist; live Elementor/XPRO implementation/testing remains pending |

**Important:** matching section counts does not prove the content or visual effects were converted one-to-one. V3 deliberately replaces legacy media-heavy/unverified sections with approved text-only and holding-state structures.

## 5. What is converted, replaced or excluded

| Legacy item | V3 outcome |
|---|---|
| Cinematic static hero | Replaced by text-only editorial hero / optional safe slider source |
| Generated hero artwork slides | Excluded until approved media exists |
| Legacy brand `Biya Gallery Art & Craft` | Replaced by `Biya’s Art Gallery` |
| `Creative Content` label | Excluded permanently |
| Static collection/product cards | Replaced by Verified Artwork CPT architecture/holding states |
| 70 programmed Surah Rehman crops | Excluded; Third Art requires approved individual Artwork folio records |
| Founder full-name / unverified claims | Excluded from public V3 frontend; Biya Jee only |
| Static contact forms | Scheduled for WPForms conversion |
| Static header/footer | Replaced by XPRO source layouts/manual build maps |

## 6. Conversion defects still open

1. **V3 HTML → Elementor is not a pixel-for-pixel translation.** The generated JSON has governed five-Container structural layouts, but it does not yet recreate every rich static legacy section/effect.
2. **XPRO Header/Footer are source/manual files, not verified active global templates.**
3. **No staging Elementor/OCDI/XPRO test has confirmed imported pages are editable and assigned correctly.**
4. **WPForms has not yet replaced static inquiry/contact forms.**
5. **No verified Artwork, Artist, Event, Book, Project, Punjabi Verha, Press or Journal records exist for dynamic archive testing.**
6. **No approved media assets are available for a real three-image hero carousel.**

## 7. Audit conclusion

### Numeric result
- **HTML page coverage:** complete at route-map level — 15/15 legacy pages mapped.
- **V3 reference coverage:** 33 page/global reference files.
- **Section count parity:** 67 legacy sections and 67 V3 reference sections.

### Operational result
The V3 project is **structurally converted and documented**, but not yet verified as a fully operational Elementor/XPRO WordPress site. The remaining work is runtime conversion validation, XPRO template assignment, WPForms setup and verified-data onboarding.

**Runtime/staging verification: PENDING.**  
**Production publication approval: NOT GRANTED.**
