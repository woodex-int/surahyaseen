# Biya's Art Gallery — Project Completion Master

**Project identity:** Biya's Art Gallery  
**Descriptor:** Art | Poetry | Culture | Lahore  
**Founder display:** Biya Jee — **[APPROVED ENGLISH SPELLING] Khursheed**  
**Status:** Stage 1 active — planning and content verification only. No production frontend edits authorised by this plan.

## Delivery stages
1. **Stage 1 — Brand, Content & Archive:** source verification, content inventory, asset registers, page content map, SEO and translation queue.
2. **Stage 2 — Frontend & WordPress:** only after Stage 1 approval; global system, templates, migration and forms.
3. **Stage 3 — QA, SEO & Launch:** only after Stage 2; P0/P1/P2 launch audit and deployment readiness.

## Non-negotiable publishing rules
- Never use `Creative Content`.
- Never publish AI-generated, repeated placeholder or sample imagery as real artwork.
- Do not describe a placeholder 70-folio grid as a real archive.
- Do not publish unverified claims of national, museum, award, record, ownership or “first” status.
- Original artworks and Third Art folios use Request Price, Request Details, Enquire on WhatsApp or Arrange a Private Viewing — never checkout.
- Books, prints and repeatable editions may only receive checkout after catalogue, payment, fulfilment, delivery and returns approval.

## Source of truth files
- `PROJECT_START.md`
- `agents/01-brand-content-archive.md`
- `agents/02-frontend-wordpress-system.md`
- `agents/03-qa-seo-launch.md`
