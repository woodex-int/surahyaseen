# Biya Gallery Art & Craft — Complete Website Page Mapping & Architecture

**Version:** 1.0  
**Purpose:** master page map for design, content, development, SEO and launch planning.

---

## 1. Full website architecture

```text
BiyaArtGallery.pk
│
├── /  Home — Cinematic Gallery Entrance
├── /collections.html  Shop & Collection Hub
│   └── /product.html?slug={artwork-slug}  Artwork Detail Template
├── /custom-studio.html  Custom Studio & Wall Estimator
├── /gallery.html  Interior Gallery
├── /portfolio.html  Installations & Visual Portfolio
├── /third-art.html  The Third Art Exhibition
│   └── #archive  Surah Rehman 70-Folio Handmade Archive
├── /founder.html  Biya Jee / Naghmana Khursheed
├── /poetry.html  Punjabi Poetry & Publications
├── /journal.html  Journal / Studio Notes
├── /events.html  Exhibitions, Readings & Cultural Programs
├── /visit.html  Private Viewings & Appointments
├── /b2b.html  Trade / Interior Designer / Hospitality Portal
├── /contact.html  Contact & Showroom
├── /faq.html  Collector & Commission Guide
├── /about.html  About the Gallery & Craftsmanship
├── /privacy.html  Privacy Policy
├── /terms.html  Terms, Commission & Delivery Policies
└── /404.html  Not Found / Recovery Page
```

---

## 2. Primary navigation map

### Desktop navigation

| Navigation item | Destination | Purpose |
|---|---|---|
| Gallery | `/` | Brand experience and entry point. |
| Collection ▾ | Dropdown | Shop & Collection, Custom Studio, Interior Gallery. |
| The Third Art Exhibition | `/third-art.html` | Artist-led movement and Surah Rehman archive. |
| Biya Jee | `/founder.html` | Founder story, poetry, art and cultural leadership. |
| Exhibitions | `/events.html` | Readings, private views, artist talks and cultural programs. |
| More ▾ | Dropdown | Poetry, Journal, Visit, Portfolio, Guide & FAQ. |
| CTA | `/contact.html` or Services inquiry | Start a conversation. |

### Mobile navigation
- Full-height scrollable menu.
- Collection and More dropdowns remain expanded for simple touch access.
- Final production version should add fixed WhatsApp / Call actions after official contact details are supplied.

---

## 3. Page-by-page section mapping

# 3.1 Home — `/`

| Section | Purpose | Key content | Primary CTA |
|---|---|---|---|
| Cinematic hero | Create immediate emotional entry | Biya Gallery Art & Craft visual mark, art / poetry / Thread Art message | Begin the experience |
| Opening scene | Explain brand belief | “Not decoration. A presence.” | Scroll / explore |
| Thread Art scene | Establish artistic distinction | Hand-led practice, material and nature | Explore The Third Art |
| Selected works | Present collection | Three featured works / categories | View collection |
| Poetry scene | Connect literature to visual art | Punjabi poetry as a second language | Read Biya Jee’s poetry |
| Biya Jee scene | Build founder authority | Portrait, biography, poetry collections, Ishq | Meet Biya Jee |
| Services scene | Convert for commissions | Original work, commission, private viewing | Explore services / Arrange viewing |
| Final CTA | Close the brand story | “Art is not only seen. It is lived with.” | Begin a conversation |
| Footer | Global access | Brand, links, legal, contact | Contact / Guide |

---

# 3.2 Collections / Shop — `/collections.html`

| Section | Purpose | Key content |
|---|---|---|
| Collection hero | Introduce available and archival work | “A collection of presence.” |
| Filter / sort bar | Help discovery | All works, Original Art, Thread Art, Studies, Available Now; later: price, scale, finish, search |
| Artwork grid | Browse work | Image, title, medium, year, availability |
| Quick-view panel | Fast work discovery | Larger image, short story, inquiry CTA |
| Artwork detail route | Full collector decision-making | Gallery, dimensions, medium, availability, care, related works |
| Archive prompt | Keep sold works valuable | Ask about previous / archive works |

### Product detail template — `/product.html?slug={artwork-slug}`
- Breadcrumb.
- Image gallery: main, thumbnails, close-up and in-room view.
- Title, year, medium, dimensions, edition / signature.
- Availability, price / request-price.
- Variation selector where applicable: size, material, frame / finish.
- Add to inquiry / WhatsApp button.
- Optional cart for books, prints and repeatable editions.
- Care, delivery, framing and certificate accordion.
- Related works.

---

# 3.3 Custom Studio — `/custom-studio.html`

| Section | Purpose |
|---|---|
| Studio hero | Position bespoke work as personal and considered. |
| Artwork direction selector | Calligraphy, Thread Art, original painting, statement interior work. |
| Wall measurement form | Width, height, room type and visual distance. |
| Material / finish selector | Gallery advice, gold accents, black / ivory, contemporary colour. |
| Brief / room-story field | Upload room image in final version; capture mood, deadline and budget. |
| Commission summary | Generate a visual brief; not final automated price until rates are approved. |
| Submit / WhatsApp export | Send selected brief to gallery. |

---

# 3.4 Interior Gallery — `/gallery.html`

| Section | Purpose |
|---|---|
| Interior hero | Show art in lived environments. |
| Category filters | Living room, dining, office, entrance, mosque / prayer room, hospitality. |
| Transformation cards | Before / after or room-and-art presentation. |
| Work details | Art direction, size, room context, style. |
| Get This Look | Direct commission / inquiry CTA. |

---

# 3.5 Installations & Visual Portfolio — `/portfolio.html`

| Section | Purpose |
|---|---|
| Cinematic hero | Show art placed in life. |
| Gallery philosophy | Explain culture, memory, light and architecture. |
| Portfolio grid | Calligraphy, Punjab, sacred visual worlds, interior work, private commission. |
| Commission CTA | Start a room / project conversation. |

---

# 3.6 The Third Art Exhibition — `/third-art.html`

| Section | Purpose |
|---|---|
| Exhibition hero | Introduce The Third Art. |
| Premise | Explain the artist-led proposition. |
| Language | Gesture, colour, memory and material. |
| Surah Rehman Archive | 75/25 large-view / thumbnail-rail handmade portfolio viewer. |
| Quote / note | Create emotional pause. |
| Attribution | State source and claim-verification requirements. |

### Surah Rehman archive module
- 70 folios.
- 75% large artwork view / 25% internal-scroll rail.
- Previous / next arrows and keyboard navigation.
- Full-screen artwork view.
- Selected folio inquiry handoff.
- Final content required: 70 real images, title / verse, medium, year, dimensions and availability.

---

# 3.7 Founder / Biya Jee — `/founder.html`

| Section | Purpose |
|---|---|
| Founder hero | Introduce Naghmana Khursheed / Biya Jee. |
| Biography | Poet, fiction writer, artist, social worker, columnist, founder and cultural leader. |
| Poetry legacy | Link to Folk Punjab archive and published collections. |
| Thread / Third Art process | Explain visual language and handwork. |
| Roles timeline | Founder, poet / writer, cultural leader, Thread artist. |
| Published sources | Folk Punjab and Qasim Ali Shah Foundation interview. |
| Contact CTA | Collect, collaborate or arrange conversation. |

---

# 3.8 Poetry & Publications — `/poetry.html`

| Section | Purpose |
|---|---|
| Poetry hero | Poetry as a visual and cultural force. |
| Literary practice | Connect line, thread and image. |
| Published selections | Approved Folk Punjab links. |
| Books / publications | Add three poetry collections, covers, dates and purchase / inquiry route. |
| Culture CTA | Invite readings, mehfils and literary collaboration. |

---

# 3.9 Journal — `/journal.html`

| Section | Purpose |
|---|---|
| Journal hero | Editorial home for art, craft and culture notes. |
| Featured note | The Third Art / process article. |
| Article cards | Poetry, craft, collecting, exhibition and studio notes. |
| Video / interview | Qasim Ali Shah Foundation feature. |
| Newsletter | Gallery announcements and cultural program list. |

---

# 3.10 Events & Exhibitions — `/events.html`

| Section | Purpose |
|---|---|
| Events hero | Invite cultural participation. |
| Program categories | Mehfil / poetry, artist talks, salon gatherings. |
| Calendar | Upcoming and past events; dates and venues in final build. |
| Event details | Title, time, guest, venue, access, RSVP. |
| Guest list | Poetry, art and cultural-interest signup. |

---

# 3.11 Visit — `/visit.html`

| Section | Purpose |
|---|---|
| Private viewing hero | Establish appointment-led gallery experience. |
| Visit options | Viewing, art advisory, studio / culture meeting. |
| What to expect | Request, preparation, encounter. |
| Appointment form | Name, email, intent, preferred date / time, note. |
| Location block | Add address, map, hours, parking / access and phone. |

---

# 3.12 B2B / Trade — `/b2b.html`

| Section | Purpose |
|---|---|
| Trade hero | Address designers, architects, hospitality and corporate clients. |
| Benefits | Bespoke scale, art advisory, cultural value, project support. |
| Project process | Brief, curation, production, delivery / installation. |
| Case studies | Hospitality, homes, workplace, restaurant projects. |
| Trade inquiry | Volume, timeline, location, design brief and contact fields. |
| Trade deck | Email-gated PDF download when ready. |

---

# 3.13 Contact & Showroom — `/contact.html`

| Section | Purpose |
|---|---|
| Contact hero | Direct, confident invitation to connect. |
| Contact cards | WhatsApp, call, email, private viewing. |
| Showroom information | Address, map, opening hours, appointment note. |
| General contact form | Name, email / phone, inquiry type, message. |
| Social profiles | Instagram, Facebook, YouTube and official channels. |

---

# 3.14 About & Craftsmanship — `/about.html`

| Section | Purpose |
|---|---|
| Brand story | Biya Gallery heritage and point of view. |
| Craft process | Thread, paint, metalwork / laser-cut process only where factually applicable. |
| Material principles | Handmade detail, quality, finishing and care. |
| Cultural approach | Punjab, poetry and contemporary expression. |
| CTA | Visit, commission or learn about Biya Jee. |

---

# 3.15 Guide & FAQ — `/faq.html`

- Collecting original work.
- Commissions and Thread Art.
- Private gallery visits.
- Cultural collaborations.
- Official payment, lead-time, delivery, framing, installation and returns information after approval.

---

# 3.16 Legal & utility routes

| Route | Required content |
|---|---|
| `/privacy.html` | Form data, newsletter, cookies, contact rights. |
| `/terms.html` | Terms of use, commissions, delivery, returns, copyright. |
| `/404.html` | Branded recovery with Gallery, Collection and Contact CTAs. |

---

## 4. Global conversion paths

```text
Home → Collection → Artwork Detail → Inquiry / WhatsApp → Private Viewing / Sale
Home → Custom Studio → Commission Brief → Gallery Review → Quote / Deposit
Founder / Poetry / Third Art → Events / Services → Cultural Collaboration
Portfolio / Interior Gallery → Get This Look → Commission Brief
B2B → Trade Brief → Curation Call → Proposal / Installation
```

---

## 5. Build status

### Built / designed
Home, Collection, Custom Studio starter, Interior Gallery starter, Portfolio, Third Art, Surah Rehman archive, Founder, Poetry, Journal, Events, Visit and FAQ.

### Still required for final launch
- Full product-detail route.
- B2B / Trade route.
- Contact & Showroom route.
- About & Craftsmanship route.
- Legal routes and 404 route.
- Real contact data, policy text and form routing.
- Real artwork catalogue / individual folios.
- SEO and live-domain configuration.
