# Biya Gallery Art & Craft — Product & Design Specification

## Navigation (final)
- Gallery
- **Collection** dropdown: Shop & Collection, Custom Studio, Interior Gallery
- **The Third Art Exhibition** (replaces the old Services navigation role)
- Biya Jee
- Exhibitions
- More: Poetry, Journal, Visit, Portfolio, Guide & FAQ
- Primary CTA: Start a Conversation

## Design language
**Tone:** cinematic, reverent, contemporary Pakistani, art-first.  
**Palette:** evergreen `#122622`, espresso `#18130e`, rich gold `#c9a54d`, champagne `#f7f1e5`.  
**Type:** editorial serif for cultural storytelling; quiet sans/mono for interface and artwork metadata.  
**Motion:** slow camera drift, opacity + translate reveals, no excessive effects. Respect reduced-motion preferences.

## Required routes
| Route | Purpose | Key elements |
|---|---|---|
| `/` | Gallery home | Hero, value proposition, collection, Thread Art, poetry, conversion CTA |
| `/collections.html` | Shop / catalogue | Filters, availability, collection cards, quick view |
| `/custom-studio.html` | Custom Studio & Wall Estimator | Room brief, dimensions, material / frame selector, live visual estimate, inquiry export |
| `/gallery.html` | Portfolio & Interior Gallery | Living / office / dining / prayer filters, room transformations, Get This Look CTA |
| `/third-art.html` | The Third Art Exhibition | Exhibition statement, craft language, Surah Rehman 70-folio archive |
| `/founder.html` | Biya Jee | Biography, poetry, practice, cultural leadership |
| `/events.html` | Exhibitions / events | Poetry readings, artist talks, cultural programs, RSVP |
| `/about.html` | About & Craftsmanship | Brand heritage, making / process, quality statement |
| `/b2b.html` | Trade / B2B | Designer and hospitality benefits, bulk inquiry |
| `/contact.html` | Contact & Showroom | Address, map, email, phone, WhatsApp, appointment form |
| `/product.html` | Product-detail template | Image gallery, metadata, size / material / finish, care, related works |

## Home required modules
1. Announcement bar (delivery / appointment message only after policy confirmed).
2. Cinematic hero.
3. Trust/value grid: artist-led, handmade, bespoke scale, secure consultation.
4. Curated categories: Calligraphy, Thread Art, Punjab / landscape, interior art.
5. Featured collection.
6. Embedded Custom Studio prompt.
7. Interior transformation gallery.
8. Poetry / founder proof.
9. Testimonials only with client permission.
10. Footer and contact path.

## Custom Studio rules
- Do not show final automated pricing until rates are approved.
- Show an estimated project brief instead: artwork type, dimensions, finish, palette, intended room.
- Export the brief to the contact form / WhatsApp when official number is supplied.

## Catalogue data required per work
Title, artist, year, medium, dimensions, framing, availability, price or inquiry status, description, images, alt text, rights approval.

## Launch requirements
Official contact details, policy text, real collection data, image rights confirmation, form integration, sitemap, robots.txt, analytics consent and mobile QA.
