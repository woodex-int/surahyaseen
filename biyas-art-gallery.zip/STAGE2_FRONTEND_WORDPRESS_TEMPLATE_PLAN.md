# Stage 2 — WordPress-Ready Frontend & Template Plan

**Status:** planning only. This document does not authorise publication of unverified content or production changes until the owner approves the resulting implementation backlog.

## 1. Stage 2 constraints from Agent 01

| Constraint | Implementation rule |
|---|---|
| Founder name | Frontend displays only `Biya Jee` until official English spelling is approved. Full-name verification state is WordPress-admin-only. |
| Artwork records | Render only records with `verification_status = Verified` and approved image rights. |
| Third Art | Use approved artist-led wording only; no historical distinction claims. |
| Surah Rehman | Do not show a 70-folio grid as completed. Use an archive holding state until 70 separate approved folios exist. |
| Library | Do not publish `20+` count, titles or purchase status until records are supplied. |
| Originals / folios | Use Request Price, Request Details, Enquire on WhatsApp or Arrange a Private Viewing; no checkout. |
| Books / editions | Checkout remains disabled until catalogue, payments, fulfilment, delivery and returns are approved. |

## 2. Global information architecture

### Primary menu
- Home
- Artworks
  - Available Works
  - Collections
  - The Third Art
  - Archive / Sold Works
  - Gallery Artists
- Biya Jee
  - Biography
  - Art and Installations
  - Poetry and Writing
  - Books and Library
  - Media and Interviews
- Punjabi Verha
  - About Punjabi Verha
  - Monthly Events
  - Mushairas
  - Muqalma and Dialogues
  - Video Archive
  - Media Coverage
  - Join / Collaborate
- Exhibitions and Events
- Projects and Interiors
- Commissions and Custom Studio
- Trade and Hospitality
- Media and Press
- Visit / Contact

### Global components
1. Announcement bar — disabled until a verified delivery, event or appointment message exists.
2. Header — logo, accessible desktop dropdowns, mobile disclosure menu, Collector CTA.
3. Footer — verified contacts only; otherwise “Contact details forthcoming” must not be shown publicly.
4. Request Price module — original and folio enquiry path.
5. Private Viewing module.
6. WhatsApp module — hidden until official number is approved.
7. Data state module — loading, empty, pending-verification, unavailable and error states.
8. Consent / legal links — required before any live form or analytics deployment.

## 3. WordPress data model

### Custom post types
| CPT | Archive / single URL | Required template |
|---|---|---|
| Artwork | `/artworks/`, `/artworks/{slug}/` | Archive, card, single artwork |
| Collection | `/collections/`, `/collections/{slug}/` | Collection landing / curator statement |
| Artist | `/artists/`, `/artists/{slug}/` | Artist profile |
| Exhibition/Event | `/events/`, `/events/{slug}/` | Event archive / single event |
| Project/Installation | `/projects/`, `/projects/{slug}/` | Project detail |
| Book/Library Item | `/library/`, `/library/{slug}/` | Library archive / item |
| Punjabi Verha Event | `/punjabi-verha/`, `/punjabi-verha/{slug}/` | Programme template |
| Press/Media Item | `/press/`, `/press/{slug}/` | Press archive / source item |
| Journal Article | `/journal/`, `/journal/{slug}/` | Article template |

### Taxonomies
- `availability`: available, reserved, sold, archive, commission-reference, pending-verification
- `art_type`: original-art, thread-art, calligraphy, print, edition
- `medium`, `artwork_collection` (public label: Collection), `artwork_artist` (public label: Artist), `year`, `language`, `event_type`, `location`, `project_type`

`collection` and `artist` are reserved for the Collection and Artist custom post types and their public routes; they must not be registered as taxonomy slugs.

### Required system fields
Every record uses: `verification_status`, `source_url`, `source_owner`, `rights_status`, `last_verified_date`, `alt_text`, `caption`, `cta_mode`.

## 4. Reusable component specification

### Artwork card
- Verified hero image or neutral `Artwork record forthcoming` state.
- Title only if approved.
- Medium, year, dimensions only if verified.
- Availability badge.
- CTA mode: Request Price / Request Details / Private Viewing.
- Never display cart control for originals.

### Archive holding state
**Copy:** “The Surah Rehman archive is being digitised folio by folio. Request archive information or arrange a private viewing.”
- No fake 70-image rail.
- No repeated crop grid.
- Shows only approved cover image if rights are confirmed.

### Collection state
- Empty state: “This collection is being prepared by the gallery.”
- Filter UI must return “No verified works currently shown” rather than duplicate placeholders.

### Book / library state
- Bibliographic cards only after title, author, cover, year and language are supplied.
- Purchase button hidden by default; use “Request details” until commerce policy approved.

### Event state
- Date, venue, guests and RSVP only when verified.
- Draft / past / cancelled labels are editorial backend states, not assumptions.

### Press item
- Outlet, date and source URL required before publication.
- No screenshot or summary without source rights / verification.

## 5. Forms and destinations

| Form | Fields | Destination | Publication state |
|---|---|---|---|
| Collector enquiry | artwork / folio, name, email, city, room, budget comfort, timeline | CRM/email + WhatsApp when approved | Build only after contact destination supplied |
| Private viewing | name, contact, preferred date, interest | booking workflow | Pending business hours / contact |
| Commission brief | room type, dimensions, art type, palette, budget, timeline, upload | studio review inbox | Pending contact / policy |
| Trade brief | company, project type, rooms, dimensions, budget, install date | trade inbox / CRM | Pending contact / policy |
| Event RSVP | event, name, contact, guest count / access requirement | event workflow | Pending events data |
| Punjabi Verha collaboration | organisation, proposal, date, contact | Punjabi Verha coordinator | Pending coordinator contact |

## 6. Responsive, accessibility and motion requirements
- Test at 360px, 768px and 1280px+.
- Header dropdowns: keyboard accessible, Escape close, focus return, touch disclosure mode.
- Galleries/lightboxes: focus trap, Escape close, arrow controls, captions, no auto-open.
- Reduced-motion: disable parallax, autoplay, camera drift and non-essential transitions.
- Images: defined width / height, responsive sources, WebP/AVIF, lazy-load below first viewport.
- Forms: label every field, inline error, server error, success notice, consent record.

## 7. WordPress migration approach
1. Freeze current static site as visual reference only.
2. Build a block theme or custom theme with global header/footer and template parts.
3. Configure CPTs, taxonomies and ACF field groups.
4. Import only Agent 01 Verified content.
5. Implement neutral empty states for Pending Verification content.
6. Connect form provider / CRM only after owner supplies destinations and policy text.
7. Add staging domain and content review workflow before production migration.

## 8. Stage 3 handoff deliverables
Agent 02 must provide:
- Final route list and redirects.
- Component and template inventory.
- CPT / taxonomy / field map.
- Form destinations and consent logic.
- Per-page metadata fields.
- Image sizes and optimisation specification.
- Accessibility test status.
- Known gaps still marked Pending Verification.
