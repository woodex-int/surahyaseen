# Biya's WP — OCDI One-Click Import Master Plan

**Decision:** replace the custom one-click page importer with **One Click Demo Import (OCDI)** as the temporary import engine.  
**Theme:** standalone Biya’s WP parent theme + optional child theme. No Hello Elementor dependency.  
**Persistent companion:** one Biya’s WP Master Plugin only.  
**Elementor:** free version only; Containers and native free widgets only.  
**XPRO:** installed separately by the site owner; it is never bundled in the theme or plugin.

## 1. What changes from the previous package

| Previous element | New OCDI architecture |
|---|---|
| Custom master-plugin page importer | Removed from the production plan. OCDI imports the packaged demo XML. |
| ACF package | Excluded completely. The Master Plugin provides native WordPress editorial metaboxes. |
| Two functional plugins | One permanent Master Plugin + the temporary third-party OCDI importer only. |
| Generic Elementor JSON as primary import | JSON remains a reference/manual recovery source. The primary import is a WXR XML export containing real Elementor post meta. |
| Automatic XPRO assignment | Not attempted. XPRO assignment is performed manually after import because its Theme Builder data is version/plugin specific. |

## 2. Why OCDI fits this project

OCDI is designed for theme authors to define demo import files inside a theme. It imports WordPress content XML, optional widgets and compatible settings after the user clicks an import action. Once the import is complete, the imported WordPress posts, menus and meta remain in the database; OCDI can be deactivated and deleted after the post-import verification is complete.

**Critical limitation:** deleting OCDI is safe only after import verification. The permanent Biya’s WP Master Plugin must stay active because it registers the project’s CPTs, taxonomies, validation rules and controlled archive behaviours.

## 3. Final package architecture

```text
biyas-wp-theme.zip                   Required standalone parent theme
├── demo-content/
│   ├── biya-safe-draft-demo.xml      OCDI WordPress WXR content export
│   ├── widgets.wie                   Optional widget export; omit if no widgets
│   ├── customizer.dat                Generated only from same Biya theme build
│   ├── elementor-kit.json            Elementor Site Settings export/reference
│   ├── elementor-json/               Per-template recovery/import JSON
│   └── README-IMPORT.md
├── inc/ocdi.php                      Registers the local OCDI demo
├── inc/after-import.php              Creates menu locations and gives XPRO instructions
└── theme files

biyas-wp-child.zip                   Optional; not active during initial import
biyas-wp-master-plugin.zip           Only permanent project plugin
```

## 4. The single permanent Master Plugin

The Master Plugin remains responsible for everything that must still work after OCDI is deleted:

1. Register approved CPTs: Artwork, Collection, Artist, Event, Project, Book, Punjabi Verha Event, Press Item and Journal Article.
2. Register approved taxonomies, including `artwork_collection` and `event_type`.
3. Provide native WP metaboxes instead of ACF.
4. Store Artwork → Artist with `artist_profile` relationship field; no Artist taxonomy.
5. Enforce one permitted Event Type before an Event is published.
6. Enforce Third Art folio requirements for Artwork records where `art_type=third-art-folio`.
7. Prevent non-Verified/non-rights-approved content from controlled archive queries.
8. Provide safe holding-state shortcodes/templates where approved data does not exist.
9. Detect Elementor and XPRO, then report the remaining setup actions.

The Master Plugin must **not** depend on OCDI after import.

## 5. OCDI demo import data — exact scope

### Import as drafts only
The WXR file includes structural pages and editable Elementor layouts, all as **Draft**:

- Home
- Artworks
- Collections
- The Third Art
- Biya Jee
- Punjabi Verha
- Events
- Projects and Interiors
- Commissions and Custom Studio
- Trade and Hospitality
- Books and Library
- Media and Press
- Visit / Contact
- Guide
- Privacy
- Terms and Policies
- Header source layout
- Footer source layout

### Include
- Page titles, final slugs and parent structure.
- Actual Elementor `_elementor_data` exported from a reference WordPress site.
- Elementor containers, headings, text, buttons, dividers, icon lists and any approved free widgets.
- Approved holding-state copy.
- WordPress menu items.
- Native site design settings / Elementor Kit export when generated from the same versioned reference environment.

### Do not include
- Artwork inventory, folios, biographies, media claims, fake image assets, contact numbers, social accounts or checkout.
- Any material marked Pending Verification or Not for Publication.
- An automatically active WhatsApp number.
- XPRO global template assignments.

## 6. Correct build method for a proven WXR import

A hand-authored XML / generic JSON file is not sufficient proof of Elementor compatibility. The theme must be proven with a **reference WordPress build**:

1. Create a clean local WordPress reference site with the exact target PHP, WordPress, Elementor Free and Biya’s WP theme versions.
2. Activate Biya’s WP Master Plugin first so CPTs / taxonomies exist.
3. Build every page in Elementor using Containers and supported free widgets only.
4. Create Header/Footer source layouts in Elementor Saved Templates.
5. Create the approved draft holding-state layouts; do not create false art records.
6. Export **All Content** from WordPress Tools → Export. This generates the actual WXR XML with Elementor meta.
7. Export Elementor Site Settings / Kit JSON.
8. Add the WXR and same-theme settings files to `demo-content/`.
9. Register those local files through the `ocdi/import_files` theme hook.
10. Create a brand-new empty test WordPress site and run OCDI.
11. Open every imported draft using Elementor; confirm elements appear, are editable and do not create Inner Sections/Atomic Elements/HTML widgets.
12. Repair failures, re-export from reference site, and repeat until pass.

Only after that test is passed may the WXR be called **proven and tested**.

## 7. XPRO plan

XPRO is not included or imported automatically.

After OCDI import:

1. Manually install/activate XPRO.
2. Confirm Master Plugin detects it.
3. Open the imported Header source layout from Elementor Saved Templates.
4. Create **Biya’s Art Gallery | Global Header** in XPRO Theme Builder.
5. Insert/rebuild the source layout using XPRO + free Elementor-compatible components.
6. Assign the template to Entire Site.
7. Save the final Header to XPRO Library.
8. Repeat for **Biya’s Art Gallery | Global Footer**.
9. Verify no standalone theme header/footer is duplicated on the frontend.

## 8. OCDI installation and deletion procedure

1. Make a complete backup and use staging.
2. Upload/activate `biyas-wp-theme.zip`.
3. Upload/activate `biyas-wp-master-plugin.zip`.
4. Install and activate Elementor Free.
5. Install and activate OCDI temporarily.
6. Go to Appearance → Import Demo Data.
7. Select **Biya’s WP — Safe Draft Foundation** and start the import once.
8. Verify every imported page is a Draft and opens in Elementor with Containers.
9. Configure XPRO Header/Footer manually, menu locations, WPForms, site settings and homepage.
10. Run the complete acceptance test.
11. **Only after all verification passes**, deactivate and delete OCDI.
12. Keep Biya’s WP Master Plugin active permanently.

## 9. Acceptance tests before deleting OCDI

- [ ] OCDI completes without PHP, import or media errors.
- [ ] All expected pages, menu and Saved Template source layouts are present exactly once.
- [ ] All pages are Draft; none of the imported content is publicly published by default.
- [ ] Every imported page opens in Elementor and contains editable Containers / native free widgets.
- [ ] No Elementor HTML widget, Pro widget, Atomic Element or Inner Section exists.
- [ ] Theme activates without error and design tokens/styles render.
- [ ] Master Plugin is active and all CPTs/taxonomies/editor rules appear.
- [ ] Header/Footer are manually assigned through XPRO and saved in its Library.
- [ ] Default header/footer and duplicate page title do not render.
- [ ] WPForms are configured and mail is tested.
- [ ] Third Art and Event validation rules work.
- [ ] Mobile, accessibility and contrast tests pass.

## 10. Current status and next build action

**Current state:** architecture and JSON reference package exist, but a true WXR exported from a live reference WordPress environment has not yet been generated or verified. It would be inaccurate to label the existing generic JSON as a proven one-click demo.

**Next build action:** refactor `biyas-wp-theme.zip` to register the OCDI local demo files, retire the custom importer UI from the permanent plugin, and prepare the WXR/Elementor reference-export pipeline. The one-click package is released only after the clean-site import test passes.
