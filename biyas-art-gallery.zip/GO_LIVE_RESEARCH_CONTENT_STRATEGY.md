# Biya Gallery Art & Craft — Go-Live & Research Content Strategy

**Brand position:** *Not decoration. A presence.*  
**Official domain target:** `BiyaArtGallery.pk`

## Phase 1 — Research Content Strategy

### 1. Cataloguing & Folio Digitalisation
**Objective:** create a reliable, collector-ready record of every artwork and every Surah Rehman folio.

| Task | Required metadata | Deliverable |
|---|---|---|
| Digitise 70 Surah Rehman folios | Folio number, title / verse if approved, year, medium, dimensions, condition, availability, image rights | 70-image archive + metadata sheet mapped to artwork slugs |
| Photograph artworks | Full work, texture close-up, framed / edge view, in-room image, artist / process view | Image library for Collection and Product pages |
| Create artwork records | Slug, title, series, artist, medium, dimensions, availability, price-on-request decision, description, alt text | Complete catalogue data source |
| Approve images | Ownership, source, edit permissions, religious / cultural context | Production-safe asset library |

### 2. Literary & Biographical Curation
**Objective:** publish a factual, culturally grounded founder narrative.

- Compile approved published Punjabi poetry collection details.
- Record Folk Punjab links and media references.
- Prepare an artist narrative covering Biya Jee’s literary practice, Thread Art origin and The Third Art.
- Confirm exact spelling, titles, appointments, dates, publications and source links.
- Obtain approved English / Urdu / Shahmukhi Punjabi excerpts only where rights permit.

**Deliverables:** approved copy for `/founder.html`, `/poetry.html`, `/third-art.html`, Journal and Exhibition pages.

### 3. Commercial & Advisory Setup
**Objective:** establish trusted collector and trade journeys without making unsupported pricing promises.

- Define commission deposit and studio-review process.
- Define lead-time ranges by medium / scale.
- Define framing, installation, local delivery and international shipping scope.
- Define cancellation, return, care and certificate-of-authenticity policies.
- Define B2B structure: trade eligibility, advisory scope, tier / volume ranges, design brief process.

**Deliverables:** approved content for `/faq.html`, `/terms.html`, `/b2b.html`, Contact / Showroom and downloadable trade deck.

## Phase 2 — Go-Live Execution Roadmap

### Step 1: Core content & routes
- Finalise `/product.html`, `/b2b.html`, `/contact.html`, `/about.html`, `/privacy.html`, `/terms.html` and `/404.html`.
- Replace demonstration content with approved data.
- Connect forms to WhatsApp, email / CRM and appointment workflow.

### Step 2: Technical polish & interactivity
- Test Surah Rehman 75/25 viewer at mobile, tablet and desktop breakpoints.
- Replace reference image crop generator with real 70-folio data object.
- Complete Custom Studio brief generator and export the selected brief.
- Add form error states, consent checkbox and spam protection.

### Step 3: SEO, deployment & QA
- Add unique title, description, canonical and Open Graph fields across all pages.
- Implement JSON-LD: `VisualArtwork`, `Person`, `LocalBusiness`, `Event` and `ProfessionalService` once data is confirmed.
- Connect `BiyaArtGallery.pk`, SSL, sitemap, robots.txt and Search Console.
- Optimise images as WebP / AVIF and add width, height, alt text and lazy loading.
- Perform cross-browser, mobile, keyboard, accessibility and performance QA.

## Priority order
1. Real contact / policy / form routing.
2. Real product and Surah Rehman metadata.
3. Remaining routes and B2B system.
4. Domain, SEO and production QA.
