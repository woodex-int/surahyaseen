# Biya Gallery Art & Craft — Master Website Plan

**Brand line:** Original art, poetry, Thread Art and craft by Biya Jee.

## 1. Brand direction — approved foundation
- **Identity:** Biya Gallery Art & Craft (old brand mark restored in the hero).
- **Palette:** Evergreen `#122622`, espresso `#18130E`, rich gold `#C9A54D`, champagne `#F3E4AA`, gallery paper `#F7F1E5`.
- **Typography:** expressive editorial serif for art and authorship; quiet, precise sans/mono for navigation and metadata.
- **Image direction:** dark gallery lighting, real work first, hand/process close-ups, no generic product mockups.

## 2. Final information architecture
1. **Home** — cinematic welcome, featured works, Third Art, collector enquiry.
2. **The Third Art** — the movement statement, method, 70-work archive, research context.
3. **Founder / Biya Jee** — sourced biography, poetry, Thread Art, cultural leadership and sources.
4. **Collections** *(next)* — filters for Original Art, Thread Art, Poetry & Books, Craft / Commissions.
5. **Work detail** *(next)* — artwork image set, dimensions, medium, availability, enquiry / WhatsApp action.
6. **Visit / Collect** *(next)* — private appointments, showroom details, collector form, FAQ.

## 3. Completed UX / UI work
- Original **Biya Gallery Art & Craft** visual mark is now used as the cinematic homepage hero artwork.
- Unified luxury color and contrast system: evergreen, espresso, gold and paper.
- Rebuilt navigation, premium CTA behavior, homepage typography, work-card hover states, mobile hierarchy, form states and footer contrast.
- Added editorial Thread Art and collector-salon visual assets.
- Founder page includes public source links to Folk Punjab and the Qasim Ali Shah Foundation interview.
- The Third Art has a 70-tile interactive visual archive.

## 4. Hero creative direction
**Concept: “Enter the archive.”**
- A dark, illuminated gallery corridor is the immediate visual. The original brand mark appears at the image centre; value proposition appears low-left so it never competes with the mark.
- A subtle 6% camera push gives depth without feeling like an effect.
- Slow ambient grain and a deep black-to-evergreen vignette create a theatre-like entry.
- First scroll moves visitors from the gallery threshold to the brand’s point of view: “Not decoration. A presence.”
- Mobile preserves the brand mark and pushes the value line into the lower safe area.

## 5. Motion system
- **Timing:** 450–800ms for interface transitions; 900–1200ms for editorial reveals.
- **Easing:** `cubic-bezier(.2,.8,.2,1)` — soft arrival, no bounce.
- **Load:** hero image performs a single continuous 6% camera push; headline and eyebrow rise 16–24px with opacity.
- **Scroll:** section copy rises once; work imagery reveals through a simple opacity/translate motion.
- **Hover:** cards lift 7px with shadow only; CTA arrow creates additional gap. No rotation or aggressive scale.
- **Cursor:** standard system cursor retained for performance and accessibility. Archive tiles are clearly interactive and open a lightbox.
- **Reduced motion:** animations already switch off automatically for users with motion preferences.

## 6. Launch checklist / missing inputs
- [ ] Confirm official spelling: **Naghmana Khursheed** vs **Naghmana Khurshid**; use the same spelling globally.
- [ ] Confirm title wording for Punjabi Virsa and Arts & Culture presidency, plus organisation names and dates.
- [ ] Provide official Biya Gallery phone, WhatsApp number, email, gallery address and appointment hours.
- [ ] Supply a selected set of 12–20 original work images with title, year, medium, dimensions, price / availability.
- [ ] Supply 70 unique archive images or give approval to convert the visual index from placeholders to real works.
- [ ] Supply approved portrait photography of Biya Jee to replace the interview-thumbnail crop where needed.
- [ ] Approve a short brand/about statement and first-person founder quote.
- [ ] Connect the form to WhatsApp, email or CRM; front-end confirmation is currently a demo.
- [ ] Add Privacy Policy, Shipping / Returns and Commission Terms before taking payments.
- [ ] Compress final images to WebP/AVIF and add meaningful alt text before deployment.
