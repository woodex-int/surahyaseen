# Stage 2 — Complete Page, Section, Header & Footer Plan

**Status:** implementation-planning package. No production migration or publication is authorised until owner approval.

## 1. Global header

### Desktop structure
1. Logo: **Biya's Art Gallery**
2. Descriptor: **Art | Poetry | Culture | Lahore**
3. Primary menu:
   - Home
   - Artworks (dropdown)
   - Biya Jee (dropdown)
   - Punjabi Verha (dropdown)
   - Exhibitions and Events
   - Projects and Interiors
   - Commissions and Custom Studio
   - Trade and Hospitality
   - Media and Press
   - Visit / Contact
4. Primary CTA: **Arrange a Private Viewing**
5. WhatsApp utility appears only after official number approval.

### Header behaviour
- Sticky after first viewport.
- Desktop dropdowns: keyboard focus, Enter / Space open, Escape close, focus return.
- Mobile: expandable disclosure menu; no hover dependency.
- Founder label always reads **Biya Jee** until official English spelling is approved.

## 2. Global footer

### Columns
- Brand statement: “Not decoration. A presence.”
- Explore: Artworks, The Third Art, Biya Jee, Punjabi Verha.
- Visit: appointment, contact and approved social links.
- Collector services: Request Price, Commission Brief, Trade inquiry.

### Legal / operations row
- Privacy, Terms, Commission Policy, Delivery & Returns, Copyright.
- Contact details only after verified.
- Newsletter only after consent and destination are configured.

## 3. Page and section map

| Route | Page sections | Data state requirement |
|---|---|---|
| `/` | Hero, brand statement, featured verified works, pillars, events, CTA | Empty-state when no verified work / event exists |
| `/artworks/` | Filters, artwork grid, Request Price CTA, archive / sold link | Verified Artwork CPT records only |
| `/artworks/{slug}/` | Gallery, data, story, availability, Request Price, care, related works | Hide unverified fields |
| `/collections/` | Collection cards, curatorial statements | Verified Collection records only |
| `/artworks/the-third-art/` | Project introduction, approved statement, approved records | Holding state until approved definition / folios |
| `/biya-jee/` | Biography, practice, sources, CTA | Public label only `Biya Jee` until spelling confirmed |
| `/biya-jee/art-installations/` | Art / installation projects | Rights-approved Project records |
| `/biya-jee/poetry-writing/` | Poetry, writing, approved source links | No excerpts without rights approval |
| `/library/` | Book cards, details, approved purchase / enquiry CTA | Holding state until bibliography exists |
| `/biya-jee/media-interviews/` | Verified interviews and media records | Source required |
| `/punjabi-verha/` | Purpose, culture, join CTA | Independent content pillar |
| `/punjabi-verha/events/` | Monthly events | Verified Punjabi Verha Event records |
| `/punjabi-verha/mushairas/` | Mushaira archive | `event_type=mushaira` |
| `/punjabi-verha/muqalma/` | Dialogue archive | `event_type=muqalma` |
| `/punjabi-verha/video/` | Video archive | Verified video URLs / rights |
| `/punjabi-verha/media/` | Media coverage | Verified Press Item records |
| `/events/` | Exhibitions / events grid and RSVP | Required `event_type` |
| `/projects-interiors/` | Project / interior gallery | Rights-approved Project records |
| `/commissions/` | Studio brief, safe estimate request | No binding price engine |
| `/trade-hospitality/` | Benefits, case studies, trade brief | No tiers until approved |
| `/press/` | Press archive | Source required |
| `/visit-contact/` | Location, contacts, form, appointment | Holding state until details supplied |
| `/guide/` | Collector / commission FAQ | Official policy content required |
| `/privacy/`, `/terms/`, `/404/` | Compliance / recovery pages | Required before live launch |

## 4. Required reusable sections
- Hero: optional verified media, eyebrow, title, body, CTA.
- Holding state: neutral image / no-artwork representation, transparent explanation, inquiry CTA.
- Artwork card and single detail.
- Source citation block.
- Event card and RSVP block.
- Book card and library detail.
- Press card.
- Project / installation card.
- Inquiry form and consent block.
- Rich text / quote / editorial split section.

## 5. Approval gate for implementation
Approve this document and the JSON schema package only after reviewing:
- routes and header navigation;
- holding-state wording;
- content types / fields;
- form pathways;
- no direct checkout for originals;
- no frontend full founder spelling until verified.
