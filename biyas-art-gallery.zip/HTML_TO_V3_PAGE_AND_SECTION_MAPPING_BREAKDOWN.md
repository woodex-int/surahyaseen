# Biya’s Art Gallery — Legacy HTML to Theme V3 Page & Section Mapping Breakdown

**Purpose:** detailed legacy HTML page/section map against the V3 WordPress theme/reference architecture.  
**Scope:** 15 legacy static pages / 67 legacy sections compared with 31 V3 route pages plus 2 global source layouts.

## Status key

- **Mapped** — a V3 route/template exists for this legacy purpose.
- **Rebuilt** — V3 uses a new governed/WordPress structure rather than copying legacy markup.
- **Holding state** — V3 intentionally shows no record/media until verified content exists.
- **Excluded** — legacy material must not migrate under content governance.
- **Pending runtime** — route/template source exists but target-site Elementor/XPRO test is still required.

---

# 1. Global system comparison

| Legacy static system | Theme V3 system | Status |
|---|---|---|
| Header with `BIYA GALLERY / Art & Craft` | XPRO Header source: **Biya’s Art Gallery / Art \| Poetry \| Culture \| Lahore** | Rebuilt; pending XPRO assignment |
| Gallery/Collection/More static navigation | Final WordPress menu with Artworks, Biya Jee, Punjabi Verha, Events, Projects, Commissions, Trade, Press and Visit | Rebuilt; pending WordPress/XPRO menu setup |
| Static footer | XPRO Footer source and manual build map | Rebuilt; pending XPRO assignment |
| Static contact forms | WPForms plan | Pending configuration |
| Static CSS background images | Elementor Containers plus approved media only | Rebuilt / governed |
| Static JS hero slider | Optional V3 text-only slider plugin | Rebuilt; optional |

---

# 2. Home conversion map — `index.html` → `home.html`

**Legacy sections:** 8  
**V3 route:** `/`  
**V3 reference sections:** 3 HTML sections; 5 Elementor Container sections.

| # | Legacy HTML section | Legacy purpose | V3 page / section target | Conversion action | Status |
|---:|---|---|---|---|---|
| 1 | `cinema-hero` | Three-image cinematic hero, title lockup, slider controls | Home → Hero / optional editorial slider | Rebuild as text-only editorial hero; use approved media only in future | Mapped; media excluded |
| 2 | `opening-scene` | Gallery introduction | Home → Editorial context | Rebuild with approved brand positioning | Mapped |
| 3 | `craft-scene` | Thread Art proposition | Home → The Third Art / cultural pillar | Rebuild as governed Third Art introduction | Mapped |
| 4 | `collection-reveal` | Sample featured work cards | Home → Artworks holding module | Replace static cards with verified Artwork query or holding state | Holding state |
| 5 | `poetry-scene` | Poetry pillar | Home → Biya Jee / Poetry cultural pillar | Rebuild as route CTA; no unapproved excerpts | Mapped |
| 6 | `biya-portrait-scene` | Founder bio/portrait/book | Home → Biya Jee CTA | Public label Biya Jee only; verified source/rights required | Rebuilt / governed |
| 7 | `services-drift` | Services/private viewing | Home → Private conversation CTA | Rebuild with WPForms route and enquiry-only original art pathway | Mapped; WPForms pending |
| 8 | `home-final` | Final gallery CTA | Home → Private conversation conversion section | Rebuild with Visit/Contact CTA | Mapped |

## Home exclusions
- `Creative Content` title lockup — excluded permanently.
- Generated slide images — excluded as gallery/artwork media.
- Sample titles `Language of Light`, `The Flower Remembers`, `After the Verse` — excluded until verified records exist.

---

# 3. Artwork / Collection conversion map

## `collections.html` → V3 Artwork and Collection family

**Legacy sections:** 4  
**V3 routes:** `/artworks/`, `/artworks/{slug}/`, `/collections/`, `/collections/{slug}/`, archive/sold works.

| # | Legacy section | V3 target | Conversion action | Status |
|---:|---|---|---|---|
| 1 | `collection-hero` | Artworks archive hero / Collections archive hero | Rebuilt as V3 archive intro | Mapped |
| 2 | `collection-toolbar` | Artwork archive filters | Connect only to verified Artwork taxonomy data | Pending dynamic data |
| 3 | `catalogue-grid` | Artwork CPT archive grid | Replace static cards with Verified + approved-rights Artwork query | Holding state until records exist |
| 4 | `catalogue-note` | Collector/archive note | Rebuild as governed archive notice | Mapped |

## `product.html` → `artwork-single.html`

**Legacy sections:** 1

| Legacy section | V3 target | Conversion action | Status |
|---|---|---|---|
| `product-detail` | Artwork Single | Dynamic Artwork details, Artist relationship, request-only CTA, no original checkout | Template mapped; data pending |

## `gallery.html` and `portfolio.html` → Project family

| Legacy page / section | V3 target | Conversion action | Status |
|---|---|---|---|
| `gallery.html` → page hero | Projects archive hero | Rebuilt as V3 Projects/Interiors archive | Mapped |
| `gallery.html` → portfolio grid | Project cards | Rights-approved Project CPT grid only | Holding state |
| `portfolio.html` → portfolio hero | Projects archive hero | Rebuilt | Mapped |
| `portfolio.html` → portfolio intro | Project editorial context | Rebuilt | Mapped |
| `portfolio.html` → portfolio grid | Project archive grid | Dynamic Project CPT data only | Holding state |
| `portfolio.html` → CTA | Trade / commissions CTA | Rebuilt | Mapped |

---

# 4. Third Art conversion map

## `third-art.html` → `/the-third-art/`

**Legacy sections:** 6  
**V3 rule:** every folio is an Artwork CPT record where `art_type = third-art-folio`.

| # | Legacy section | V3 target | Conversion action | Status |
|---:|---|---|---|---|
| 1 | Third Art hero | Third Art editorial hero | Rebuild without unsupported exhibition claim | Mapped |
| 2 | `premise` | Third Art editorial context | Rebuild using approved definition only | Pending approved text |
| 3 | `art-language` | Technique/process context | Rebuild only from verified source material | Pending verification |
| 4 | `archive-surah` | Surah Rehman controlled archive | Query Verified Artwork records with `art_type=third-art-folio` | Holding state |
| 5 | `quote-band` | Approved quote/editorial block | Do not use unverified quote | Pending verification |
| 6 | `research-note` | Archive note/source block | Rebuild from rights/source-approved documentation | Pending verification |

## Excluded Third Art behaviour

| Legacy behaviour | V3 decision |
|---|---|
| 70 programmed crops from one image | Excluded permanently |
| Folio labels 01–70 represented as real individual records | Excluded until 70 approved distinct Artwork records exist |
| Direct/static inquiry metadata | Replace with WPForms Request Details / private-viewing flow |

---

# 5. Biya Jee / Poetry conversion map

## `founder.html` → Biya Jee, Poetry/Writing, Media/Interviews

**Legacy sections:** 7

| # | Legacy section | V3 target | Conversion action | Status |
|---:|---|---|---|---|
| 1 | `founder-hero` | Biya Jee hero | Public label only **Biya Jee** | Mapped / name-governed |
| 2 | `bio` | Biya Jee biography | Publish only verified biography/source content | Holding/approved source needed |
| 3 | `poetry-strip` | Poetry & Writing route | Direct approved archive/source links | Mapped |
| 4 | `process` | Art/installation practice | Approved Project / practice material only | Pending verification |
| 5 | `timeline` | Biography timeline | Do not migrate without verified dates/evidence | Excluded pending evidence |
| 6 | `sources` | Source citation block / Media route | Use verified external references | Mapped |
| 7 | `founder-contact` | Visit/Contact and private-viewing flow | WPForms required | Pending WPForms |

## `poetry.html` → `poetry-writing.html`

**Legacy sections:** 5

| Legacy section | V3 target | Conversion action | Status |
|---|---|---|---|
| Poetry hero | Poetry/Writing hero | Rebuilt | Mapped |
| Poetry intro | Editorial/source introduction | Verified language only | Pending source review |
| Poem index | Approved published-work links | No unapproved poem excerpts | Holding/source-link state |
| Poetry note | Approved quote block | Source required | Pending verification |
| Poetry contact | Collaboration/contact CTA | WPForms | Pending WPForms |

---

# 6. Punjabi Verha and Events conversion map

## `events.html` → Events and Punjabi Verha event family

**Legacy sections:** 5

| # | Legacy section | V3 target | Conversion action | Status |
|---:|---|---|---|---|
| 1 | `events-hero` | Events archive hero | Rebuilt | Mapped |
| 2 | `events-intro` | Event archive editorial context | Rebuilt | Mapped |
| 3 | `programs` | Event / Punjabi Verha cards | Only Verified records, required Event Type | Holding state |
| 4 | `future-program` | Future event CTA | Use neutral future gathering/CV CTA | Mapped / no claims |
| 5 | `rsvp-section` | Event RSVP | WPForms Event RSVP only after notification setup | Pending WPForms |

## New V3 Punjabi Verha routes absent in legacy HTML

| New V3 route | Purpose | Content state |
|---|---|---|
| `/punjabi-verha/` | Independent cultural pillar hub | Holding state |
| `/punjabi-verha/events/` | Programme archive | Verified Punjabi Verha Event records only |
| `/punjabi-verha/mushairas/` | Mushaira archive | `event_type=mushaira` |
| `/punjabi-verha/muqalma/` | Muqalma archive | `event_type=muqalma` |
| `/punjabi-verha/video/` | Video archive | Rights/source-cleared video only |

---

# 7. Commercial / service conversion map

| Legacy page / sections | V3 route | Conversion action | Status |
|---|---|---|---|
| `custom-studio.html` — hero, studio brief | `/commissions/` | Commission overview + WPForms Commission Brief | Template mapped; form pending |
| `services.html` — hero, intro, service list, commission scene, proof, contact | `/commissions/` and `/trade-hospitality/` | Split into two governed routes; no unsupported service claims | Mapped / content pending |
| `b2b.html` — hero, trade section, trade brief | `/trade-hospitality/` | Trade/hospitality route + WPForms brief | Template mapped; form pending |
| `visit.html` — hero, intro, options, ritual, appointment | `/visit-contact/` | Private viewing/contact route; verified address/contact only | Template mapped; contact data pending |
| `faq.html` — hero, guide, FAQ area, final CTA | `/guide/` | Guide/FAQ source | Policy content pending |

---

# 8. Editorial / utility conversion map

| Legacy page / sections | V3 route | Conversion action | Status |
|---|---|---|---|
| `journal.html` — hero, feature, list, video, signup | `/journal/` | Journal Article archive; verified content only | Template mapped; content pending |
| Legacy footer guide links | `/guide/`, `/projects-interiors/` | Final V3 routes/WordPress menu | Pending XPRO menu |
| No legacy Privacy page | `/privacy/` | New V3 utility page | Legal text pending |
| No legacy Terms page | `/terms/` | New V3 utility page | Legal/policy text pending |
| No legacy 404 page | `/404/` | New V3 recovery template | Runtime theme assignment pending |

---

# 9. Count comparison breakdown

| Group | Legacy pages | Legacy sections | V3 target/template files | V3 reference sections |
|---|---:|---:|---:|---:|
| Global header/footer | embedded | not counted | 2 | 4 |
| Home | 1 | 8 | 1 | 3 |
| Artwork / Collection / Project | 4 | 11 | 8 | 16 |
| Third Art | 1 | 6 | 1 | 2 |
| Biya Jee / Poetry / Media | 2 | 12 | 3 | 6 |
| Events / Punjabi Verha | 1 | 5 | 7 | 14 |
| Commissions / Trade / Visit / Guide | 5 | 20 | 4 | 8 |
| Journal / Press / legal / 404 | 1 | 5 | 7 | 14 |
| **Total** | **15** | **67** | **33** | **67** |

## 10. Final conversion interpretation

### Complete at architecture level
- All 15 legacy pages are mapped to a V3 page family.
- V3 adds missing public pillars, single templates, utility pages and global source layouts.
- Numeric reference section parity is 67 legacy sections and 67 V3 sections.

### Not complete at operational runtime level
- V3 Elementor templates must still be imported/tested in the target WordPress environment.
- Header/Footer must still be created and assigned in XPRO.
- WPForms must replace all live form paths.
- Verified records and approved media must be supplied before dynamic archives become populated.

**Runtime/staging verification: PENDING.**  
**Production publication approval: NOT GRANTED.**
