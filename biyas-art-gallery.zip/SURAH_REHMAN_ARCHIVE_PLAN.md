# Surah Rehman Archive — Interaction & Improvement Plan

## Current presentation
- **Gallery card:** 75% large artwork viewer / 25% archive rail.
- **70 folios:** one dedicated handmade portfolio index, numbered 01–70.
- **Desktop rail:** fixed-height internal scroll only; the page itself does not jump when a folio changes.
- **Mobile:** large viewer first, followed by a compact two-column internal archive rail.

## Interaction logic now implemented

### Folio selection
1. A visitor clicks a folio in the right rail.
2. The system sets that folio as the active state.
3. The left viewer updates its image crop, folio title and `01 / 70` counter.
4. The selected rail item receives the active visual state and `aria-current=true`.
5. The rail scrolls only far enough to keep the selected item visible.

### Previous / next controls
- Left arrow changes to the previous folio.
- Right arrow changes to the next folio.
- The sequence loops: 01 → previous → 70; 70 → next → 01.
- Keyboard Left / Right arrows work when the main viewer has focus.

### Full-screen artwork view
- Clicking the large artwork opens a full-screen display.
- The selected artwork crop is preserved in the expanded view.
- Click the artwork again, click the close button, click the dark surrounding area, or press Escape to return to the archive.
- Page scrolling is locked while the full-screen viewer is open.

### Inquiry handoff
- “Inquire about this work” passes the active folio into the Services form URL.
- The inquiry form is prefilled with: `Surah Rehman — Folio XX`.
- This prevents ambiguous collector messages and preserves the selected-work context.

## Bugs fixed
- [x] Removed `scrollIntoView`, which could scroll the main page instead of just the right archive rail.
- [x] Added local rail scrolling through `archiveRail.scrollTo()`.
- [x] Made active thumbnail state and large viewer state use one shared `active` folio value.
- [x] Ensured left/right navigation loops safely at 01 and 70.
- [x] Added click and keyboard controls to the artwork viewer.
- [x] Added stable full-screen close actions.
- [x] Improved right rail information so every thumbnail includes a folio number, Surah Rehman title and handmade-study label.

## Content needed to make all 70 folios fully authentic
The current archive creates visual variations from the supplied Surah Rehman portfolio reference. To turn it into a final documentary archive, provide:

- [ ] 70 individual folio image files, named `01` to `70`.
- [ ] Exact title / Surah Rehman verse or section for each folio, if appropriate.
- [ ] Medium and handwork technique.
- [ ] Dimensions and completion year.
- [ ] Availability: available, private collection, not for sale or commission reference.
- [ ] Optional audio recitation / artist note for each chapter.

## Recommended next enhancement
Once individual folios are supplied, replace the single-image crop generator with a `surahFolios` data object. Each record should include:

```js
{
  number: 1,
  title: 'Surah Rehman — Folio 01',
  subtitle: 'Handmade calligraphy study',
  image: 'assets/surah-rehman/01.webp',
  availability: 'Inquire'
}
```

This will allow exact images, captions, dimensions, availability and catalogue-quality collector inquiries for every folio.
