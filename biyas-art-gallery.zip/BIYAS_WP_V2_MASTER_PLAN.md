# Biya's WP v2 — Standalone Theme, Child Theme & One-Click Import Master Plan

> **Superseded for import workflow:** use `BIYAS_WP_OCDI_IMPORT_MASTER_PLAN.md`. The confirmed import engine is temporary One Click Demo Import (OCDI), not the custom importer described in this earlier plan.

**Approved architecture:** standalone Biya parent theme + optional child theme + one master plugin.  
**Import mode:** safe drafts and approved holding states only.  
**Elementor:** free Elementor, Containers and native free widgets only. No Elementor Pro, Atomic Elements, Inner Sections or HTML widgets.  
**XPRO:** not bundled. The master plugin detects XPRO and provides post-import setup guidance after manual installation.

## 1. Deliverables

| Deliverable | Role |
|---|---|
| `biyas-wp-theme.zip` | Standalone, Elementor-compatible parent theme with Biya visual tokens, fallback header/footer, menu locations and safe WhatsApp configuration. |
| `biyas-wp-child.zip` | Optional child theme for future safe overrides; not required for initial install. |
| `biyas-wp-master-plugin.zip` | The only required companion plugin: CPTs/taxonomies, native WordPress editorial fields, verification workflow, one-click draft import, WordPress menu setup, Elementor builder data, JSON exports and XPRO readiness check. |
| `biyas-wp-elementor-templates.zip` | Complete template JSON reference and manual import files for all planned routes. |
| `BIYAS_WP_V2_INSTALL_AND_QA.md` | Exact installation, XPRO setup, verification and QA instructions. |

## 2. Explicit exclusions

- No ACF JSON package.
- No second CPT plugin.
- No separate Elementor installer plugin.
- No bundled XPRO, Elementor, One Click Demo Import or Elementor Pro code.
- No fake artwork, repeated gallery imagery, invented archives, phone number, social profile or checkout for originals.

## 3. One master plugin responsibilities

1. Register all approved CPTs and taxonomies.
2. Create native WordPress metaboxes for verification, rights, Artist relationship, artwork details, Third Art folios and Event data.
3. Enforce required `event_type` before an Event can publish.
4. Enforce required Third Art folio fields before a `third-art-folio` Artwork can publish.
5. Keep non-Verified content out of controlled Third Art/frontend queries.
6. Supply a secure admin-only **One-Click Safe Draft Import**.
7. Create all planned WordPress pages as drafts with editable Elementor Container data.
8. Create a primary WordPress menu without assigning unpublished pages as live links.
9. Create saved Elementor Header/Footer source layouts.
10. Detect Elementor and XPRO; show clear admin guidance if either is missing.
11. Export the package’s Elementor JSON files for reference/manual import.

## 4. Theme design system

- Evergreen: `#122622`
- Espresso: `#18130E`
- Gold: `#C9A54D`
- Champagne: `#F7F1E5`
- Container width: 1280px
- Gutter: 32px desktop / 20px mobile
- Design: editorial, quiet luxury, cultural archive; no false imagery.
- Accessible CTA: evergreen fill, champagne text, visible gold keyboard focus.

## 5. Template scope

The safe draft import creates all routes:

- Home
- Artworks archive and Artwork single source
- Collections
- The Third Art
- Biya Jee
- Punjabi Verha
- Exhibitions and Events
- Projects and Interiors
- Commissions and Custom Studio
- Trade and Hospitality
- Books and Library
- Media and Press
- Visit / Contact
- Guide
- Privacy
- Terms and Policies
- 404 source layout
- XPRO Header source layout
- XPRO Footer source layout

All are Containers with native Elementor widgets. Dynamic content and approved media are added later after verification.

## 6. One-click import safety behaviour

The importer is not a content publisher.

- Imports pages as **Draft**.
- Creates neutral approved holding-state copy only.
- Does not set a homepage automatically.
- Does not turn on WhatsApp.
- Does not create Artwork / Folio / Event content.
- Does not assign XPRO display conditions automatically; XPRO varies by installed version.
- Can be run once, with duplicate protection.

## 7. XPRO manual flow after import

1. Install/activate XPRO manually.
2. Master plugin confirms XPRO availability.
3. Open Elementor Saved Templates and edit the generated Header source layout.
4. XPRO → Theme Builder → create Header → insert source layout → assign Entire Site → save to XPRO Library.
5. Repeat for Footer.
6. Verify default theme header/footer are not duplicated.

## 8. Verification plan

### Static package verification
- PHP lint every custom PHP file.
- JSON parse every Elementor export file.
- ZIP inventory check.
- Search source for prohibited `html` Elementor widget, `inner-section`, Atomic Element and Elementor Pro widget references.

### Target-site acceptance verification
- Theme activates without PHP error.
- Master plugin activates without PHP error.
- Import creates all pages as Draft and no duplicates on second run.
- Home opens in Elementor with visible editable Containers.
- XPRO Header/Footer is manually assigned and renders site-wide.
- Event cannot publish without a valid event type.
- Third Art folio cannot publish without required fields and Verified/approved rights.
- Buttons meet contrast and keyboard checks.

## 9. Build sequence

1. Create v2 standalone parent theme and child scaffold.
2. Create v2 single master plugin / importer / native governance UI.
3. Generate Container-only Elementor layouts and JSON exports.
4. Validate package statically.
5. Package the four deliverables in a single master deployment ZIP.
6. Perform target-site installation and acceptance checklist manually.

## 10. Publication gate

No page or content becomes public until owner review, verified sources/rights, WPForms notification testing, XPRO assignment, redirect testing and Stage 3 QA approval are complete.
