# Biya Gallery Art & Craft — Complete Site Gap Analysis & Improvement Plan

**Prepared:** 23 August 2026  
**Inputs reviewed:** Current website build, existing `PROJECT_TODO.md`, `MASTER_AUDIT_DEBUG_REPORT.md`, supplied gallery brief / PRD (`biyas art gallery.md`), supplied Biya Jee biography, poetry archive, interview and artwork references.

---

## 1. Executive assessment

The website now has a strong **brand-world layer**: cinematic Home, Founder, Poetry, Third Art, Surah Rehman archive, Services, Collection, Visit, Journal, Events and Collector Guide pages. It feels much more like an artist-led cultural gallery than a commodity décor storefront.

The major gap is between **experience and operations**. The current build successfully tells the story and generates intent, but it is not yet able to fully manage a real collector journey: browse real inventory, see complete artwork data, send a live inquiry, arrange an appointment, make a payment, receive policy information or access trade services.

### Strategic recommendation
Keep the current cinematic editorial experience. Build the commercial / operational layer **underneath it**, never as a generic ecommerce skin. A visitor should always first encounter the artist, the work and the cultural story — then be given an easy, trustworthy path to collect, commission or collaborate.

---

## 2. Current sitemap vs required sitemap

| Area | Current status | Required next step |
|---|---|---|
| Home | **Complete design** | Replace demonstration work with official selected works; add live collection / inquiry data. |
| Collections | **Prototype complete** | Connect to real catalogue and improve filtering, availability, search and pagination. |
| Artwork detail | **Quick-view prototype only** | Build full individual artwork pages with image gallery, metadata, availability, related work and inquiry. |
| Founder | **Strong editorial page** | Add approved CV, publications, awards, official portrait set and verified dates. |
| Poetry | **Complete archive entrance** | Add book / publication data, original approved excerpts and potential bilingual reading options. |
| The Third Art | **Strong concept page** | Add approved artist statement, final terminology and real process / portfolio records. |
| Surah Rehman Archive | **Interactive prototype complete** | Supply 70 individual folios and exact captions / dimensions / availability. |
| Services | **Complete design** | Add official lead times, pricing approach, delivery / install scope and live form routing. |
| Visit | **Complete design** | Add confirmed address, map, appointment hours, contact channels and live booking. |
| Events | **Complete design** | Add real calendar, dates, hosts, venue details, capacity and working RSVP delivery. |
| Journal | **Structure complete** | Add recurring approved articles, images, tags and publishing workflow. |
| FAQ / guide | **Structure complete** | Replace general guidance with official commerce, delivery and policy answers. |
| Contact | **Missing as a dedicated page** | Build Contact / Showroom page with map, WhatsApp, email, phone, hours and contact form. |
| Custom Studio / estimator | **Missing** | Build commission brief / wall-size estimator from the supplied PRD. |
| Portfolio / installations | **Missing** | Build room transformation and installed-work gallery. |
| B2B / Trade | **Missing** | Build Interior Designer / hospitality / corporate partner page. |
| Cart / checkout | **Missing** | Decide whether to implement ecommerce now, or use inquiry-only collector commerce first. |
| Policy pages | **Missing** | Build Privacy, Terms, Commission Terms, Shipping / Delivery and Returns pages. |

---

## 3. Missing high-value pages

### A. Contact & Showroom page — **Priority 1**
**Purpose:** turn interest into direct, trusted communication.

**Required modules**
- WhatsApp, phone and official email.
- Lahore gallery / workshop address.
- Opening hours and appointment policy.
- Embedded Google Map or a map link.
- “Book a private viewing” CTA.
- Short general contact form.
- Social media links.

**Content needed from Biya Gallery**
- Official WhatsApp number.
- Email and phone number.
- Exact address, map pin and hours.
- Preferred response time.

---

### B. Full artwork-detail template — **Priority 1**
The Collection page currently provides an elegant quick-view. A serious collector needs a complete artwork record.

**Required modules**
- Full-size image gallery: full work, close detail, in-room view, artist / process view.
- Artwork title, year, medium, dimensions, edition and signature / provenance note.
- Availability badge: Available, Reserved, Sold, Commission Reference.
- Price or “Price on Request.”
- Inquiry button with prefilled work identity.
- Certificate / authenticity, framing, delivery and care notes.
- Related works.

**Content needed for every work**
- [ ] Title
- [ ] Year
- [ ] Medium
- [ ] Dimensions
- [ ] Price / inquiry-only decision
- [ ] Availability
- [ ] 3–5 high-resolution images
- [ ] 40–90-word work note

---

### C. Custom Studio / Commission Brief — **Priority 1**
The supplied PRD calls for a wall estimator. This should be redesigned as a luxury commission tool, not a generic calculator.

**Experience plan**
1. Choose artwork direction: Original Painting, Thread Art, Islamic Calligraphy, Cultural / Poetry-led piece.
2. Upload / describe the room.
3. Enter approximate width and height.
4. Choose visual mood, palette and desired timing.
5. Receive a polished “Commission Brief” summary by email / WhatsApp.

**Avoid publishing automatic exact pricing** until material, labor, framing and delivery formulas are approved. Start with **“Request an estimate”**, then add pricing logic later.

---

### D. Installations & Portfolio page — **Priority 2**
**Purpose:** prove how Biya Gallery work lives in real environments.

**Required content types**
- Homes: living, dining, entrance, study, prayer space.
- Hospitality: hotels, restaurants, salons, offices.
- Before / after wall transformations where permitted.
- Installation notes: city, work medium, scale and project challenge.
- “Create a similar feeling” CTA to commission form.

**Content needed:** 12–20 real room images with client permission.

---

### E. B2B / Trade & Cultural Partner page — **Priority 2**
**Audience:** architects, interior designers, hotels, restaurants, corporate teams, cultural institutions, publishers and event partners.

**Required modules**
- Trade benefits and commission process.
- Art curation for hospitality / workplace projects.
- Bulk / project inquiry form.
- Cultural programming and poetry-event collaboration.
- Case studies once available.
- Downloadable trade deck after email capture.

---

### F. Policy & trust pages — **Priority 1 before payments**
- Privacy Policy
- Terms of Use
- Commission Terms
- Delivery / Shipping
- Returns / Cancellation
- Artwork Care
- Copyright / image-use policy

---

## 4. Content gaps

### Founder / biography
**Current strength:** founder page now correctly conveys poet, artist, writer, cultural voice and gallery founder.

**Still needed**
- Confirm official spelling globally: **Naghmana Khursheed** / **Naghmana Khurshid**.
- Approved chronology / CV.
- Names and dates of three poetry collections.
- Awards, publications, exhibitions, interviews and cultural appointments with dates.
- Exact organisation name and date range for Punjabi Virsa chairperson role.
- Exact organisation and date range for President, Arts & Culture role.
- Approved quote in Biya Jee’s own voice.

### Artwork / collection
- The site needs reliable artist-owned images rather than repeated crop variations.
- Confirm which supplied calligraphy works are original, reference, commissionable or sold.
- Capture titles and correct Arabic / Urdu / Punjabi meanings only after artist review.
- Do not present religious work as available for sale without the artist’s explicit approval and an appropriate provenance / context note.

### Poetry / publications
- Titles are available through Folk Punjab; add only approved original excerpts or translations.
- Create a “Books & Publications” collection after the three collection names, covers, publication dates and purchasing / availability information are confirmed.

### Events
- Existing event experience is ready. It needs confirmed programs, event dates, venues, capacity and RSVP channel.

### Social proof
- Add only permissioned collector testimonials.
- Add press logos / press excerpts only with verifiable source and rights.
- Add project case studies after client approval.

---

## 5. UX / UI improvement opportunities

### Navigation
The site now has nine primary links. This is usable on larger screens, but a luxury gallery should feel more selective.

**Recommendation for final production navigation**
- Gallery
- Collection
- Services
- The Third Art
- Biya Jee
- **More** menu: Poetry, Journal, Events, Visit, Guide & FAQ

This removes visual crowding while preserving every page.

### Homepage
**Current strength:** cinematic and story-led.

**Next improvements**
- Add a “Now showing” block only when genuine current work / program data is available.
- Add a single “Featured Work” with exact metadata.
- Add one understated trust line: “Private viewings · Commissions · Lahore & worldwide” after delivery policy is confirmed.
- Keep visual motion restrained; do not add more effects.

### Collections
- Add search once real catalogue exceeds 20 works.
- Add sort: newest, available, medium, scale.
- Support Sold Archive to build prestige without mixing sold works into current availability.
- Add a clear legend for “Available,” “Reserved,” “Private Collection” and “Commission Reference.”

### Accessibility
- Final real images need alt text written by a human who knows each work.
- Add form error messages, not only `required` browser validation.
- Confirm color contrast on final live photography.
- Ensure full-screen Surah Rehman viewer is tested with keyboard and mobile screen-reader environments.

---

## 6. Technical / operational gaps

### Required for launch
- [ ] Connect forms to an approved inbox / WhatsApp / CRM.
- [ ] Add spam protection (honeypot or CAPTCHA) after live form routing is added.
- [ ] Create a content data source: CMS, JSON files, Shopify / WooCommerce, Airtable or a lightweight admin panel.
- [ ] Implement image compression (WebP / AVIF), size attributes and lazy loading.
- [ ] Configure domain, HTTPS, analytics consent, sitemap, robots.txt, canonical URLs and Search Console.
- [ ] Add error page / 404 page.
- [ ] Add Cookie / Privacy consent if tracking tools are activated.

### Commerce decision required
Choose one of two correct models before building checkout:

| Model | Best for | What to build |
|---|---|---|
| **Inquiry-led collector model** | Originals, commissions, high-value / bespoke work | Inquiry, private viewing, invoice / bank transfer workflow. |
| **Direct ecommerce model** | Prints, books, smaller craft objects, standard editions | Stock, cart, checkout, payment gateway, shipping rates and returns. |

**Recommendation:** start with inquiry-led commerce for original works and commissions. Add direct checkout later for books, prints or repeatable craft editions.

---

## 7. Phased build plan

### Phase 1 — Business readiness (next)
1. Collect official contact, address, policy and social information.
2. Connect all existing forms.
3. Build dedicated Contact / Showroom page.
4. Create policy pages.
5. Finalise navigation into a primary + More-menu structure.

### Phase 2 — Real collector catalogue
1. Gather first 12–20 official works.
2. Build full artwork-detail page template.
3. Replace demo Collection data.
4. Add available / sold archive logic.
5. Create the Custom Commission Brief experience.

### Phase 3 — Proof and partnerships
1. Build Installations & Portfolio.
2. Build B2B / Trade portal.
3. Add approved testimonials, case studies and press.
4. Publish first real event calendar and Journal entries.

### Phase 4 — Scale and optimise
1. Implement CMS / admin system.
2. Add direct ecommerce for eligible editions / books if desired.
3. Add bilingual English / Urdu / Shahmukhi Punjabi content.
4. Run performance, accessibility and SEO audit on the live domain.

---

## 8. Immediate information request checklist

Please provide these items to begin Phase 1 without guessing:

- [ ] Official business name for legal / SEO use.
- [ ] WhatsApp number, email, phone.
- [ ] Address, map URL, hours and appointment rules.
- [ ] Instagram, Facebook, YouTube and other official links.
- [ ] Payment methods and country / delivery coverage.
- [ ] Commission deposit, lead-time and cancellation rules.
- [ ] Shipping / returns / framing / installation policies.
- [ ] Exact founder spelling and official titles.
- [ ] First 12–20 artwork records.
- [ ] 70 individual Surah Rehman folios when available.

## Final recommendation
The visual foundation is now strong enough to represent a serious, distinctive gallery. The next improvement is not another visual redesign: it is **trust, real data and live communication**. Completing those elements will turn the current cinematic experience into a functioning gallery platform.
