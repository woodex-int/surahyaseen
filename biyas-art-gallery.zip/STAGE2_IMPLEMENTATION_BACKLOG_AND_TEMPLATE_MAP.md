# Stage 2 — Implementation Backlog & WordPress Template Map

**Status:** Approved for implementation planning only. Do not migrate, publish or expose Pending Verification records.

## Corrections applied
1. Reserved taxonomy slugs: use `artwork_collection`; public label remains **Collection**. Artist is an ACF Relationship field (`artist_profile`) targeting the Artist CPT, not a taxonomy.
2. Founder frontend label: show only **Biya Jee** until official English spelling is approved. Full-name verification belongs in WordPress admin fields only.
3. Third Art folios are Artwork CPT records with `art_type = third-art-folio`; no separate Folio content model exists.
4. Event records require `event_type`: exhibition, mushaira, muqalma, talk, private-viewing or other.
5. Stage 3 must test 301 redirects from every legacy static `.html` URL to its final WordPress route.

---

## A. WordPress template map

| Content type | CPT slug | Archive template | Single template | Public route |
|---|---|---|---|---|
| Artwork | `artwork` | `archive-artwork.php` | `single-artwork.php` | `/artworks/`, `/artworks/{slug}/` — includes approved Third Art folios |
| Collection | `collection` | `archive-collection.php` | `single-collection.php` | `/collections/`, `/collections/{slug}/` |
| Artist | `artist` | `archive-artist.php` | `single-artist.php` | `/artists/`, `/artists/{slug}/` |
| Exhibition / Event | `event` | `archive-event.php` | `single-event.php` | `/events/`, `/events/{slug}/` |
| Project / Installation | `project` | `archive-project.php` | `single-project.php` | `/projects/`, `/projects/{slug}/` |
| Book / Library Item | `book` | `archive-book.php` | `single-book.php` | `/library/`, `/library/{slug}/` |
| Punjabi Verha Event | `punjabi_verha_event` | `archive-punjabi_verha_event.php` | `single-punjabi_verha_event.php` | `/punjabi-verha/`, `/punjabi-verha/{slug}/` |
| Press / Media | `press_item` | `archive-press_item.php` | `single-press_item.php` | `/press/`, `/press/{slug}/` |
| Journal Article | `journal_article` | `archive-journal_article.php` | `single-journal_article.php` | `/journal/`, `/journal/{slug}/` |

## B. Taxonomy map

| Internal slug | Public label | Applies to |
|---|---|---|
| `artwork_collection` | Collection | Artwork |
| `availability` | Availability | Artwork, Book |
| `art_type` value `third-art-folio` | Third Art Folio | Artwork only; not a separate CPT or model |
| `medium` | Medium | Artwork, Project |
| `art_type` | Art Type | Artwork |
| `year` | Year | Artwork, Project, Book |
| `language` | Language | Book, Poetry, Press |
| `event_type` | Event Type | Event, Punjabi Verha Event |
| `location` | Location | Event, Project |
| `project_type` | Project Type | Project |

## C. Required ACF / content fields

### Universal governance fields
- `verification_status`: Verified / Pending Verification / Not for Publication
- `source_owner`
- `source_url`
- `rights_status`
- `last_verified_date`
- `internal_notes`

### Founder admin-only fields
- `founder_full_name_verified` — boolean
- `founder_official_english_name` — hidden from frontend unless boolean is true
- Public fallback display is always `Biya Jee`

### Artwork fields
`artwork_images, artwork_story, dimensions, price_policy, certificate_status, availability_note, request_price_enabled, request_details_enabled, private_viewing_enabled, artist_profile`

`artist_profile` is an ACF Post Object / Relationship field targeting the Artist CPT. It is not a taxonomy.

### Third Art folio fields — stored on Artwork CPT only
For any Artwork record where `art_type = third-art-folio`, require:
`folio_number, folio_image, title_or_verse, approved_translation, archive_note, rights_status, verification_status`

The Surah Rehman archive query is strictly: `post_type = artwork` + `art_type = third-art-folio` + `verification_status = Verified`. Until results exist, render the archive holding state only.

### Event fields
`event_type, event_date, event_time, venue, guests, programme, event_images, video_url, press_links, rsvp_mode`

`event_type` is required and limited to: `exhibition`, `mushaira`, `muqalma`, `talk`, `private-viewing`, `other`.

## D. Component backlog

| ID | Component | Priority | Dependency | Publication rule |
|---|---|---:|---|---|
| S2-01 | Global header / navigation | P0 | final information architecture | links can be built; no unverified labels |
| S2-02 | Global footer | P0 | contact/legal data | leave contact fields hidden until verified |
| S2-03 | Artwork card | P0 | verified artwork record | neutral holding state otherwise |
| S2-04 | Artwork single template | P0 | verified work metadata | Request Price only for originals |
| S2-05 | Collection template | P0 | `artwork_collection` taxonomy | show no fake works |
| S2-06 | Surah Rehman archive holding state | P0 | 70 folio records | do not show repeated image grid |
| S2-07 | Artist / Biya Jee template | P0 | approved name state | frontend label: Biya Jee only |
| S2-08 | Books / Library template | P1 | bibliographic register | no checkout by default |
| S2-09 | Punjabi Verha hub | P1 | event/media register | independent public pillar |
| S2-10 | Event / exhibition templates | P1 | verified date/venue | hide RSVP until approved |
| S2-11 | Project / installation template | P1 | rights-approved real images | use neutral state if missing |
| S2-12 | Press / media template | P1 | verified outlet/source | no unsourced summaries |
| S2-13 | Custom Studio brief form | P1 | form destination/policies | submit estimate request, never binding quote |
| S2-14 | Private viewing / trade / RSVP forms | P1 | verified inbox/CRM | validation + consent required |
| S2-15 | 404 and legal templates | P1 | approved legal content | required before public launch |

## E. Empty and pending states

### Artwork archive
**Message:** “Selected works are being prepared for the gallery archive. To discuss an original or a commission, request a private conversation.”

### Surah Rehman archive
**Message:** “This folio archive is being digitised with care. Individual folios will be published after image, source and rights review.”

### Books / Library
**Message:** “The Biya Jee library is being catalogued. Bibliographic records and approved excerpts will be added in stages.”

### Punjabi Verha
**Message:** “Programme history, media and future gatherings are being assembled with source review.”

## F. Form destination map

| Form | Final destination needed | Current status |
|---|---|---|
| Collector / Request Price | gallery CRM or approved inbox | Pending owner |
| WhatsApp enquiry | official WhatsApp number | Pending owner |
| Private viewing | booking inbox / calendar | Pending owner |
| Custom Studio | studio review inbox | Pending owner |
| Trade | trade coordinator inbox | Pending owner |
| Punjabi Verha collaboration | coordinator inbox | Pending owner |
| Event RSVP | event system / CRM | Pending owner |

## G. Legacy static URL → final WordPress redirect inventory

| Legacy URL | Final WordPress route |
|---|---|
| `/index.html` | `/` |
| `/collections.html` | `/artworks/` |
| `/product.html` | `/artworks/{slug}/` once a verified slug exists; otherwise `/artworks/` |
| `/custom-studio.html` | `/commissions/` |
| `/gallery.html` | `/projects-interiors/` |
| `/portfolio.html` | `/projects-interiors/` |
| `/third-art.html` | `/artworks/the-third-art/` |
| `/founder.html` | `/biya-jee/` |
| `/poetry.html` | `/biya-jee/poetry-writing/` |
| `/journal.html` | `/journal/` |
| `/events.html` | `/events/` |
| `/visit.html` | `/visit-contact/` |
| `/b2b.html` | `/trade-hospitality/` |
| `/faq.html` | `/guide/` |

**Stage 3 requirement:** implement and test a 301 redirect for each legacy URL. Capture redirect test result, final URL, HTTP status and owner in the launch report.

## H. Implementation sequence
1. Build theme shell, global header/footer and empty-state components.
2. Register CPTs, internal taxonomies and governance fields.
3. Build templates with verification gates.
4. Add form UI only; connect destinations after owner approvals.
5. Import a small verified content batch in staging.
6. Test responsive, keyboard and reduced-motion behaviour.
7. Create Stage 3 handoff: route list, components, form destinations, metadata fields and known gaps.
